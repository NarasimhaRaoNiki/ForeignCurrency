package com.rb.field.mapper;

import java.util.HashMap;
import java.util.Map;

public class FieldMapper {
	/**
	 * Method locates the map keys in the string parameter and replace those keys
	 * with the corresponding values.
	 * 
	 * @param map
	 *            - Map of keys and values
	 * @param str
	 *            - String to parse and replace keys with values.
	 * @return
	 */
	public static String replaceKeyWithValue(Map<String, String> canonicalMap, String str) {
		String res = "";
		if (str != null) {
			String[] strArr = str.split(",");
			for (int i = 0; i < strArr.length; i++) {
				res = (i == strArr.length - 1) ? res + canonicalMap.get(strArr[i])
						: res + canonicalMap.get(strArr[i]) + ",";
			}
			strArr = null;
		}
		return res;
	}

	public static String getNonCanonFilterString(Map<String, String> canonicalMap, String filter) {
		String res = "";
		if (filter != null) {
			String[] strFilterArr = filter.split(" ");
			for (int i = 0; i < strFilterArr.length; i++) {
				if (canonicalMap.containsKey(strFilterArr[i])) {
					strFilterArr[i] = FieldMapper.replaceKeyWithValue(canonicalMap, strFilterArr[i]);
				}
			}
			res = String.join(" ", strFilterArr);
			strFilterArr = null;
		}
		return res.trim();
	}

	public static void main(String[] args) {
		Map<String, String> canonicalMap = new HashMap<String, String>();
		canonicalMap.put("job-details", "jobInfoNav");
		canonicalMap.put("person-id-external", "personIdExternal");
		canonicalMap.put("is-contigent-worker", "isContigentWorker");
		canonicalMap.put("job-details.manager-details.manager-id", "jobInfoNav/managerUserNav/userId");
		canonicalMap.put("job-details.manager-details.location-details.address-details.location-zip-code",
				"jobInfoNav/locationNav/addressNavDEFLT/zipCode");

		String filter = "person-id-external eq '825140' or person-id-external eq '825141' or person-id-external eq '825142' or person-id-external eq '825143' or person-id-external eq '825142' or person-id-external eq '825143' or person-id-external eq '825144' or person-id-external eq '825145' or person-id-external eq '825146' or person-id-external eq '825147' or person-id-external eq '825148' or person-id-external eq '825149' or person-id-external eq '825150'";
		System.out.println("Old Filter: " + filter);
		String res = FieldMapper.getNonCanonFilterString(canonicalMap, filter);
		System.out.println("New Filter: " + res);
	}
}
