%dw 2.0
//GLOBAL FUNCTIONS
fun convertSFDate(vSFDate)  =
  (if(vSFDate != null) (( using (formattedDate = (vSFDate replace /\+.*$/ with '') replace /[^0-9-]/ with '')
  	(formattedDate as Number / 1000) as DateTime) as String {format : "dd-MM-yyyy HH:mm:ss"}) else null)
