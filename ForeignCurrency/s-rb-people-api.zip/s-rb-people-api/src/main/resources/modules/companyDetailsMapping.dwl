%dw 2.0
import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getCompanyDetails(vCompanyDetails,key) = 
	(
		if(vCompanyDetails != null) 
			{
  			//	("user-id": vCompanyDetails.userId) if(vCompanyDetails.userId != null)
  			"company-details": vCompanyDetails default [] map ((result , indexOfResult) -> {
					("start-date": commonDWFunctions::convertSFDate(result.startDate)) if(isKeyMatches(key,'company-details') or isKeyMatches(key,'company-details.start-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(result.endDate)) if(isKeyMatches(key,'company-details') or isKeyMatches(key,'company-details.end-date') or isKeyMatches(key,'all')),
					("pay-type": result.payTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'company-details') or isKeyMatches(key,'company-details.pay-type') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(result.lastModifiedDateTime)) if(isKeyMatches(key,'company-details') or isKeyMatches(key,'company-details.last-modified-date-time') or isKeyMatches(key,'all'))
				})
  			}
		else null
	) 