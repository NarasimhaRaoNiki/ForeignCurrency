%dw 2.0
import modules::commonDWFunctions

//GLOBAL FUNCTIONS
fun getCompanyDetails(vUserDetails) = 
	(
		if(vUserDetails != null) 
			{
  			"company-details": vUserDetails default [] map ((result , indexOfResult) -> {
					("start-date": commonDWFunctions::convertSFDate(result.startDate)) if(isEmpty(result.startDate) == false),
					("end-date": commonDWFunctions::convertSFDate(result.endDate)) if(isEmpty(result.endDate) == false),
					("pay-type": result.payTypeNav.picklistLabels.results[0].label) if(isEmpty(result.payTypeNav.picklistLabels.results[0].label) == false),
					("last-modified-date-time": commonDWFunctions::convertSFDate(result.lastModifiedDateTime)) if(isEmpty(result.lastModifiedDateTime) == false),
					"pay-comp-recurring-details": result.empPayCompRecurringNav.results default [] map ((result01 , indexOfResult01) -> {
							("pay-component-value": result01.paycompvalue) if(isEmpty(result01.paycompvalue) == false),
							("pay-component-code": result01.payComponentNav.externalCode) if(isEmpty(result01.payComponentNav.externalCode) == false),
							("pay-component-frequency": result01.payComponentNav.frequencyCodeNav.name) if(isEmpty(result01.payComponentNav.frequencyCodeNav.name) == false)
					})
			})
  			}
		else null
	) 