%dw 2.0

import * from dw::core::Arrays

import modules::commonDWFunctions
import modules::jobCodeDetails
import modules::jobAddressDetails
import modules::departmentDetails
import modules::locationDetails
import modules::managerDetails

var jobCodeDetailsSubEnitities=['job-code-details','department-details','manager-details','location-details','job-address-details','all']

fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

fun isJobCodeMatches(arr) = if(isKeyMatches(arr,'job-code-details') or isKeyMatches(arr,'all'))
							true else false
fun isDepartmentDetailsMatches(arr) = if(isKeyMatches(arr,'department-details') or isKeyMatches(arr,'all'))
							true else false	
fun isLocationDetailsMatches(arr) = if(isKeyMatches(arr,'location-details') or isKeyMatches(arr,'all'))
							true else false	
fun isManagerDetailsMatches(arr) = if(isKeyMatches(arr,'manager-details') or isKeyMatches(arr,'all'))
							true else false														
							



//GLOBAL FUNCTIONS
fun getJobDetails(vEmpDetails,key) = 
	(
		if(vEmpDetails != null) 
			{
				"job-details":vEmpDetails.jobInfoNav.results default[] map ((jobInfo,indexOfResult) -> {
					
					("start-date": commonDWFunctions::convertSFDate(jobInfo.startDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.start-date') or isKeyMatches(key,'all')),
					("created-date-time": commonDWFunctions::convertSFDate(jobInfo.createdDateTime)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.created-date-time') or isKeyMatches(key,'all')),
					("job-entry-date": commonDWFunctions::convertSFDate(jobInfo.jobEntryDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-entry-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(jobInfo.endDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.end-date') or isKeyMatches(key,'all')),
					("position-entry-date": commonDWFunctions::convertSFDate(jobInfo.positionEntryDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'position-entry-date') or isKeyMatches(key,'all')),
					("contract-end-date": commonDWFunctions::convertSFDate(jobInfo.contractEndDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'contract-end-date') or isKeyMatches(key,'all')),
					("fte": jobInfo.fte) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.fte') or isKeyMatches(key,'all')),
					("country-of-company": jobInfo.countryOfCompany) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.country-of-company') or isKeyMatches(key,'all')),
					("is-fulltime-employee": jobInfo.isFulltimeEmployee) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-fulltime-employee') or isKeyMatches(key,'all')),
					("is-union-worker": jobInfo.customString51Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.is-union-worker') or isKeyMatches(key,'job-details') or isKeyMatches(key,'all')),
					("location": jobInfo.location) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.location') or isKeyMatches(key,'all')),
					("location-description": jobInfo.locationNav.name) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.location-description') or isKeyMatches(key,'all')),
					("is-shift-employee": jobInfo.isShiftEmployee) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-shift-employee') or isKeyMatches(key,'all')),
					("department": jobInfo.department) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.department') or isKeyMatches(key,'all')),
					("department-description": jobInfo.departmentNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.department-description') or isKeyMatches(key,'all')),
					("manager-id": jobInfo.managerId) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.manager-id') or isKeyMatches(key,'all')),
					("working-days-per-week": jobInfo.workingDaysPerWeek) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.working-days-per-week') or isKeyMatches(key,'all')),
					("pay-group": jobInfo.payGroup) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-group') or isKeyMatches(key,'all')),
					("pay-group-description": jobInfo.payGroupNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-group-description') or isKeyMatches(key,'all')),
					("cost-center": jobInfo.costCenter) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.cost-center') or isKeyMatches(key,'all')),
					("termination-date": commonDWFunctions::convertSFDate(jobInfo.terminationDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.termination-date') or isKeyMatches(key,'all')),
					("division": jobInfo.division) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.division') or isKeyMatches(key,'all')),
					("position": jobInfo.positionNav.jobTitle) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position') or isKeyMatches(key,'all')),
					("business-unit":jobInfo.businessUnit) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.business-unit') or isKeyMatches(key,'all')),
					("job-function":jobInfo.customString4) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-function') or isKeyMatches(key,'all')),
					("job-sub-function":jobInfo.customString5Nav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-sub-function') or isKeyMatches(key,'all')),
					("region":jobInfo.customString33) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.region') or isKeyMatches(key,'all')),
					("division-description": jobInfo.divisionNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.division-description') or isKeyMatches(key,'all')),
					("company": jobInfo.company) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.company') or isKeyMatches(key,'all')),
					("company-description": jobInfo.companyNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.company-description') or isKeyMatches(key,'all')),
					("is-cross-border-worker": jobInfo.isCrossBorderWorker) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-cross-border-worker') or isKeyMatches(key,'all')),
					("pay-grade": jobInfo.payGrade) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-grade') or isKeyMatches(key,'all')),
					("standard-hours": jobInfo.standardHours) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.standard-hours') or isKeyMatches(key,'all')),
					("job-title": jobInfo.jobTitle) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-title') or isKeyMatches(key,'all')),
					("employee-status": jobInfo.emplStatusNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.employee-status') or isKeyMatches(key,'job-details') or isKeyMatches(key,'all')),
					("employee-type": jobInfo.employeeClassNav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-details.employee-type') or isKeyMatches(key,'all')),
					("employee-type-description": jobInfo.employeeClassNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.employee-type-description') or isKeyMatches(key,'all')),
					("job-code": jobInfo.jobCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-code') or isKeyMatches(key,'all')),
					("grade": jobInfo.customString2Nav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.grade') or isKeyMatches(key,'all')),
					("grade-description": jobInfo.customString2Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.grade-description') or isKeyMatches(key,'all')),
					("management-level": jobInfo.customString8Nav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.management-level') or isKeyMatches(key,'all')),
					("management-level-description": jobInfo.customString8Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.management-level-description') or isKeyMatches(key,'all')),
					("event": jobInfo.eventNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event') or isKeyMatches(key,'all')),
					("event-description": jobInfo.eventNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-description') or isKeyMatches(key,'all')),
					("event-reason": jobInfo.eventReasonNav.name) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-reason') or isKeyMatches(key,'all')),
					("event-reason-description": jobInfo.eventReasonNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-reason-description') or isKeyMatches(key,'all')),
					("regulatory-region": jobInfo.customString6) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.regulatory-region') or isKeyMatches(key,'all')),
					("hr-status": jobInfo.customString19Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.hr-status') or isKeyMatches(key,'all')),
					("work-location": jobInfo.workLocation) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.work-location') or isKeyMatches(key,'all')),
					("last-modified-by": jobInfo.lastModifiedBy) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.last-modified-by') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(jobInfo.lastModifiedDateTime)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("job-code-details": jobCodeDetails::getJobCodeDetails(jobInfo.jobCodeNav,key)) if(isJobCodeMatches(key) or checkIfKeyConsistsChildEntities(['job-code-details'],key)),
					("department-details": departmentDetails::getDepartmentDetails(jobInfo.departmentNav,key)) if(isDepartmentDetailsMatches(key) or checkIfKeyConsistsChildEntities(['department-details'],key)),	
					("location-details": locationDetails::getLocationDetails(jobInfo.locationNav,key)) if(isLocationDetailsMatches(key) or checkIfKeyConsistsChildEntities(['location-details'],key)),	
					("manager-details": managerDetails::getManagerDetails(jobInfo.managerUserNav,key)) if(isManagerDetailsMatches(key) or checkIfKeyConsistsChildEntities(['manager-details'],key)),
					("position-description": jobInfo.positionNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position') or isKeyMatches(key,'all'))
			})}			
		else []
	) 