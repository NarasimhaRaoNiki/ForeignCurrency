%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserDetails(vEmpDetails,key) = 
	(
		if(vEmpDetails != null) 
			{
				("user-id": vEmpDetails.userNav.userId) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.user-id') or isKeyMatches(key,'all')),
				("emp-id": vEmpDetails.userNav.empId) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.emp-id') or isKeyMatches(key,'all')),
				("status": vEmpDetails.userNav.status) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.status') or isKeyMatches(key,'all')),
				("last-modified-date-time":commonDWFunctions::convertSFDate(vEmpDetails.userNav.lastModifiedDateTime)) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.last-modified-date-time') or isKeyMatches(key,'all')),
				("username": vEmpDetails.userNav.username) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.username') or isKeyMatches(key,'all')),
				
			}
		else []
	) 