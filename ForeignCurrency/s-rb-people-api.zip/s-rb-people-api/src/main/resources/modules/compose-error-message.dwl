%dw 2.0
output application/json
---

{     
  "messageId": vars.vLogVars.messageId,
  "correlationId": correlationId,
  "transactionId":  vars.vLogVars.requestId,
  "environment": p('mule.env'),
  "id": app.name,
  "name": app.name,
  "domain": p('secure::common.domain'),
  "muleProjectName": app.name,
  "muleFlowName": p('secure::flow.name.main'),
  "sourceSystem": p('secure::mq.source.system'), // "ACTIVEMQ-QUEUE",
  "targetSystem":p('mq.destination'),
  "logType": p('secure::s.status.error'),
  "logTimeStamp": now() as String {format:p('secure::mq.log.timestamp.format')} ,//"05-12-17_17-52-05.016",
  "logDetails": vars.errorMessage,
  "errorType": error.errorType.identifier,
  "errorCode": vars.httpStatus,
  "muleComponentName": p('secure::mq.mulecomponent.name'),
  "errorDetails": error.detailedDescription,
  "errorStacktrace": error.cause.localizedMessage,
  "inputMessage": "",
  "containsSensitiveInformation": p('secure::casesensitive.flag')   
}
