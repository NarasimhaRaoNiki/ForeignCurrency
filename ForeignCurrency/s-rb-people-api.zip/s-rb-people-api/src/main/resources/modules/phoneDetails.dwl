%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getPhoneDetails(vPhoneDetails,key) = 
	(
		if(vPhoneDetails != null) 
			{
				"phoneDetails":vPhoneDetails default [] map ((phoneNav , indexOfResult) -> {
					("phone-type": phoneNav.phoneTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'person-details.phone-details') or isKeyMatches(key,'person-details.phone-details.phone-type') or isKeyMatches(key,'all')),
					("country-code": phoneNav.countryCodeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'person-details.phone-details') or isKeyMatches(key,'person-details.phone-details.country-code') or isKeyMatches(key,'all')),
					("phone-number": phoneNav.phoneNumber) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'person-details.phone-details') or isKeyMatches(key,'person-details.phone-details.phone-number') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(phoneNav.lastModifiedDateTime)) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'person-details.phone-details') or isKeyMatches(key,'person-details.phone-details.last-modified-date-time') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 