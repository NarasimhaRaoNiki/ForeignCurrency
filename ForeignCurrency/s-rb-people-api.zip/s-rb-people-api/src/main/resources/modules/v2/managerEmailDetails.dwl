%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getEmailManagerDetails(vEmailDetails,key) = 
	(
		if(vEmailDetails != null) 
			{
				"emailDetails": vEmailDetails.results default [] map ((emailNav , indexOfResult) -> {
					
					("email-address": emailNav.emailAddress) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-address') or isKeyMatches(key,'all')),
					
					("email-type-details": {
						("choice-details": {
							("email-type": emailNav.emailTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details.choice-details')  or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details.choice-details.email-type') or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details.choice-details') or isKeyMatches(key,'all'))
					} ) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details.email-type-details') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 