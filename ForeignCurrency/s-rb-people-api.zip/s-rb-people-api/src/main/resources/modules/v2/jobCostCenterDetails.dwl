%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobCostCenterDetails(vJobCostCenterDetailsNav,key)=
(
	if(vJobCostCenterDetailsNav != null)
	{
		("description": vJobCostCenterDetailsNav.description) if(isKeyMatches(key,'job-details.cost-center-details') or isKeyMatches(key,'job-details.cost-center-details.description') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)