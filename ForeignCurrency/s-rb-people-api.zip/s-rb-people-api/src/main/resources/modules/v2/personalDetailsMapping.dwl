%dw 2.0

import * from dw::core::Arrays
import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getPersonalDetails(vPersonalDetails,key) = 
	(
		if(vPersonalDetails != null) 
		{
				"personalDetailsObj": vPersonalDetails.results default[] map ((personalInfoNav,indexOfResult) -> {
					
				("start-date": commonDWFunctions::convertSFDate(personalInfoNav.startDate)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.start-date') or isKeyMatches(key,'all')),
				//("date-of-birth": commonDWFunctions::convertSFDate(personalInfoNav.dateOfBirth)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.date-of-birth') or isKeyMatches(key,'all')),
				("date-of-death": commonDWFunctions::convertSFDate(personalInfoNav.dateOfDeath)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.date-of-death') or isKeyMatches(key,'all')),
				("challenge-status": personalInfoNav.challengeStatus) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.challenge-status') or isKeyMatches(key,'all')),
				("gender": personalInfoNav.gender) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.gender') or isKeyMatches(key,'all')),
				("first-name": personalInfoNav.firstName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.first-name') or isKeyMatches(key,'all')),
				("last-name": personalInfoNav.lastName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.last-name') or isKeyMatches(key,'all')),
				("preferred-name": personalInfoNav.preferredName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.preferredName') or isKeyMatches(key,'all')),
				("middle-name": personalInfoNav.middleName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.middle-name') or isKeyMatches(key,'all')),
				("birth-name": personalInfoNav.birthName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.birth-name') or isKeyMatches(key,'all')),
				("formal-name": personalInfoNav.formalName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.formal-name') or isKeyMatches(key,'all')),
				("third-name": personalInfoNav.thirdName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.third-name') or isKeyMatches(key,'all')),				
				("end-date": commonDWFunctions::convertSFDate(personalInfoNav.endDate)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.end-date') or isKeyMatches(key,'all')),
				("last-modified-date-time": commonDWFunctions::convertSFDate(personalInfoNav.lastModifiedDateTime)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.last-modified-date-time') or isKeyMatches(key,'all')),
				("marital-status-details": {
						("choice-details": {
							("marital-status": personalInfoNav.maritalStatusNav.picklistLabels.results[0].label)  if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details.choice-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details.choice-details.marital-status')  or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details.choice-details') or isKeyMatches(key,'all'))
					
					}) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.marital-status-details') or isKeyMatches(key,'all')),
				("salutation-details": {
						("choice-details": {
							("salutation": personalInfoNav.salutationNav.picklistLabels.results[0].label)  if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.salutation-details') or isKeyMatches(key,'person-details.personal-details.salutation-details.choice-details') or isKeyMatches(key,'person-details.personal-details.salutation-details.choice-details.salutation')  or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.salutation-details') or isKeyMatches(key,'person-details.personal-details.salutation-details.choice-details') or isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.salutation-details') or isKeyMatches(key,'all'))
				})
  		}
		else []
	) 