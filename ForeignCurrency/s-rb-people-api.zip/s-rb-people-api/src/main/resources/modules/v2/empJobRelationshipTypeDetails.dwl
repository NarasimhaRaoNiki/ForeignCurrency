%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpJobRelationshipTypeDetails(vEmpJobRelationshipTypeDtlsNav,key)=
(
	if(vEmpJobRelationshipTypeDtlsNav != null)
	{
		("external-code": vEmpJobRelationshipTypeDtlsNav.externalCode) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-type-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-type-details.external-code') or isKeyMatches(key,'all'))
		
	}
	else null
	
)