%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpJobRelationshipUserDetails(vEmpJobRelationshipUserDetailsNav,key)=
(
	if(vEmpJobRelationshipUserDetailsNav != null)
	{
		("default-full-name": vEmpJobRelationshipUserDetailsNav.defaultFullName) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-user-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-user-details.default-full-name') or isKeyMatches(key,'all')),
		("email": vEmpJobRelationshipUserDetailsNav.email) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-user-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-user-details.email') or isKeyMatches(key,'all'))
		
	}
	else null
	
)