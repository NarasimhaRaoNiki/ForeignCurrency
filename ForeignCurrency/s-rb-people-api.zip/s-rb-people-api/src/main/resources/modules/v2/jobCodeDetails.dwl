%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobCodeDetails(vJobCodeDetails,key) = 
	(
		if(vJobCodeDetails != null) 
			{
				("job-code": vJobCodeDetails.regularTemporary) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.job-code') or isKeyMatches(key,'all')),
				("job-code-description": vJobCodeDetails.regularTemporaryNav.label_defaultValue) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.job-code-description') or isKeyMatches(key,'all')),
				("description": vJobCodeDetails.description) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.description') or isKeyMatches(key,'all')),
				("is-fulltime-employee": vJobCodeDetails.isFulltimeEmployee) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.is-fulltime-employee') or isKeyMatches(key,'all')),
				("is-regular": vJobCodeDetails.isRegular) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.is-regular') or isKeyMatches(key,'all')),
				("last-modified-date-time": commonDWFunctions::convertSFDate(vJobCodeDetails.lastModifiedDateTime)) if(isKeyMatches(key,'job-code-details') or isKeyMatches(key,'job-details.job-code-details') or isKeyMatches(key,'job-details.job-code-details.last-modified-date-time') or isKeyMatches(key,'all'))
			}
		else null
	) 