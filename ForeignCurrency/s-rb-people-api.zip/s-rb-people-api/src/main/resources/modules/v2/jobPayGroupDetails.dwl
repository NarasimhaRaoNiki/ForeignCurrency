%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobPayGroupDetails(vJobPayGroupDetailsNav,key)=
(
	if(vJobPayGroupDetailsNav != null)
	{
		("description":vJobPayGroupDetailsNav.description) if(isKeyMatches(key,'job-details.pay-group-details') or isKeyMatches(key,'job-details.pay-group-details.description') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)