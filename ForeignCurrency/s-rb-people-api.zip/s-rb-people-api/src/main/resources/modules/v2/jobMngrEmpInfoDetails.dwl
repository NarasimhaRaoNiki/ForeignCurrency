%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::managerEmailDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobMngrEmpDetails(vJobMngrEmpDtls,key)=
(
	if(vJobMngrEmpDtls != null)
	{
			("user-id": vJobMngrEmpDtls.userId) if(isKeyMatches(key,'job-details.manager-details.employee-details') or isKeyMatches(key,'job-details.manager-details.employee-details.user-id') or isKeyMatches(key,'all')),
			("person-id-external": vJobMngrEmpDtls.personIdExternal) if(isKeyMatches(key,'job-details.manager-details.employee-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-id-external') or isKeyMatches(key,'all')),
			("job-details": getJobMngrEmpJobDetails(vJobMngrEmpDtls.jobInfoNav,key).jobDetailsEntity) if(isKeyMatches(key,'job-details.manager-details.employee-details.job-details') or isKeyMatches(key,'all')),
			("person-details": {
				("network-id": vJobMngrEmpDtls.personNav.customString1) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details') or isKeyMatches(key,'job-details.manager-details.employee-details.person-details.network-id') or isKeyMatches(key,'all')),
				("email-details": managerEmailDetails::getEmailManagerDetails(vJobMngrEmpDtls.personNav.emailNav,key).emailDetails default []) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.email-details') or isKeyMatches(key,'all'))
			}) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details') or isKeyMatches(key,'all'))
		
	}
	else null
)

fun getJobMngrEmpJobDetails(vJobMngrEmpJobDtls,key)=
(
	if(vJobMngrEmpJobDtls != null and sizeOf(vJobMngrEmpJobDtls.results)>0)
	{
		("jobDetailsEntity": [{
				("position": vJobMngrEmpJobDtls.results[0].positionNav.jobTitle) if(isKeyMatches(key,'job-details.manager-details.employee-details.job-details') or isKeyMatches(key,'job-details.manager-details.employee-details.job-details.position') or isKeyMatches(key,'all')),
				("country-of-company": vJobMngrEmpJobDtls.results[0].countryOfCompany) if(isKeyMatches(key,'job-details.manager-details.employee-details.job-details') or isKeyMatches(key,'job-details.manager-details.employee-details.job-details.country-of-company') or isKeyMatches(key,'all'))
			}])
	}
	else
	{
		("jobDetailsEntity": [])
	}
)