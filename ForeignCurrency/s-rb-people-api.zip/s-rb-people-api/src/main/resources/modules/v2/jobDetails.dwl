%dw 2.0

import * from dw::core::Arrays

import modules::v2::commonDWFunctions
import modules::v2::jobCodeDetails
import modules::v2::departmentDetails
import modules::v2::locationDetails
import modules::v2::managerDetails
import modules::v2::jobDivisonDetails
import modules::v2::jobPayGroupDetails
import modules::v2::jobPositionDetails
import modules::v2::jobSubFunctionDetails
import modules::v2::jobCostCenterDetails
import modules::v2::jobFunctionDetails
import modules::v2::jobEmployeeTypeDetails
import modules::v2::jobEmployeeStatusDetails
import modules::v2::jobEventDetails
import modules::v2::jobEventReasonDetails
import modules::v2::jobCompanyDetails
import modules::v2::jobContractorTypeDetails
import modules::v2::jobBusinessUnitDetails
import modules::v2::empManagerEmploymentDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false
												
fun isJobCodeMatches(arr) = if(isKeyMatches(arr,'job-code-details') or isKeyMatches(arr,'all'))
							true else false
fun isDepartmentDetailsMatches(arr) = if(isKeyMatches(arr,'department-details') or isKeyMatches(arr,'all'))
							true else false	
fun isLocationDetailsMatches(arr) = if(isKeyMatches(arr,'location-details') or isKeyMatches(arr,'location-details.address-details') or isKeyMatches(arr,'location-details.address-details.county-details')  or isKeyMatches(arr,'location-details.address-details.state-details') or isKeyMatches(arr,'all'))
							true else false	
fun isManagerDetailsMatches(arr) = if(isKeyMatches(arr,'job-details.manager-details') or isKeyMatches(arr,'all'))
							true else false														
							

fun getJobDetails(vEmpJobDetails,key) = 
	(
		if(vEmpJobDetails != null) 
			{
				"jobDetailsObj": vEmpJobDetails.results default[] map ((jobInfo,indexOfResult) -> {
					//("timezone": jobInfo.timezone) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.timezone') or isKeyMatches(key,'all')),
					("employee-lob": jobInfo.customString39Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.employee-lob') or isKeyMatches(key,'job-details') or isKeyMatches(key,'all')),
					("start-date": commonDWFunctions::convertSFDate(jobInfo.startDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.start-date') or isKeyMatches(key,'all')),
					("job-seq-no": jobInfo.seqNumber) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-seq-no') or isKeyMatches(key,'all')),
					("created-date-time": commonDWFunctions::convertSFDate(jobInfo.createdDateTime)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.created-date-time') or isKeyMatches(key,'all')),
					("job-entry-date": commonDWFunctions::convertSFDate(jobInfo.jobEntryDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-entry-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(jobInfo.endDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.end-date') or isKeyMatches(key,'all')),
					("position-entry-date": commonDWFunctions::convertSFDate(jobInfo.positionEntryDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'position-entry-date') or isKeyMatches(key,'all')),
					("contract-end-date": commonDWFunctions::convertSFDate(jobInfo.contractEndDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'contract-end-date') or isKeyMatches(key,'all')),
					("fte": jobInfo.fte) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.fte') or isKeyMatches(key,'all')),
					("country-of-company": jobInfo.countryOfCompany) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.country-of-company') or isKeyMatches(key,'all')),
					("is-fulltime-employee": jobInfo.isFulltimeEmployee) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-fulltime-employee') or isKeyMatches(key,'all')),
					("location": jobInfo.location) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.location') or isKeyMatches(key,'all')),
					("is-shift-employee": jobInfo.isShiftEmployee) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-shift-employee') or isKeyMatches(key,'all')),
					("department": jobInfo.department) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.department') or isKeyMatches(key,'all')),
					("manager-id": jobInfo.managerId) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.manager-id') or isKeyMatches(key,'all')),
					("working-days-per-week": jobInfo.workingDaysPerWeek) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.working-days-per-week') or isKeyMatches(key,'all')),
					("pay-group": jobInfo.payGroup) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-group') or isKeyMatches(key,'all')),
					("cost-center": jobInfo.costCenter) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.cost-center') or isKeyMatches(key,'all')),
					("termination-date": commonDWFunctions::convertSFDate(jobInfo.terminationDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.termination-date') or isKeyMatches(key,'all')),
					("company": jobInfo.company) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.company') or isKeyMatches(key,'all')),
					("is-cross-border-worker": jobInfo.isCrossBorderWorker) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.is-cross-border-worker') or isKeyMatches(key,'all')),
					("pay-grade": jobInfo.payGrade) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-grade') or isKeyMatches(key,'all')),
					("standard-hours": jobInfo.standardHours) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.standard-hours') or isKeyMatches(key,'all')),
					("job-title": jobInfo.jobTitle) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-title') or isKeyMatches(key,'all')),
					("job-code": jobInfo.jobCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-code') or isKeyMatches(key,'all')),
					("regulatory-region": jobInfo.customString6) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.regulatory-region') or isKeyMatches(key,'all')),
					("regulatory-region-full": jobInfo.customString6Nav.externalName_defaultValue) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.regulatory-region-full') or isKeyMatches(key,'all')),
					("hr-status": jobInfo.customString19Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.hr-status') or isKeyMatches(key,'all')),
					("last-modified-on": commonDWFunctions::convertSFDate(jobInfo.lastModifiedOn)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.last-modified-on') or isKeyMatches(key,'all')),
					("position": jobInfo.positionNav.jobTitle) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position') or isKeyMatches(key,'all')),
					("work-location": jobInfo.workLocation) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.work-location') or isKeyMatches(key,'all')),
					("business-unit":jobInfo.businessUnit) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.business-unit') or isKeyMatches(key,'all')),
					("job-function":jobInfo.customString4) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-function') or isKeyMatches(key,'all')),
					("region":jobInfo.customString33) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.region') or isKeyMatches(key,'all')),
					("employee-region":jobInfo.customString33Nav.externalName) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.employee-region') or isKeyMatches(key,'all')),
					("employee-status": jobInfo.emplStatusNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.employee-status') or isKeyMatches(key,'job-details') or isKeyMatches(key,'all')),
					("event": jobInfo.eventNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event') or isKeyMatches(key,'all')),
					("event-reason": jobInfo.eventReasonNav.name) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-reason') or isKeyMatches(key,'all')),
					("business-title": jobInfo.customString28) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.business-title') or isKeyMatches(key,'all')),
					("employee-type": jobInfo.employeeClassNav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-details.employee-type') or isKeyMatches(key,'all')),
					("last-modified-by": jobInfo.lastModifiedBy) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.last-modified-by') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(jobInfo.lastModifiedDateTime)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("division": jobInfo.division) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.division') or isKeyMatches(key,'all')),
					("benefit-program": jobInfo.customString57)  if(isKeyMatches(key,'job-details.benefit-program') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("country-state": jobInfo.customString3)  if(isKeyMatches(key,'job-details.country-state') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("division-details":jobDivisonDetails::getJobDivisionDetails(jobInfo.divisionNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.division-details') or isKeyMatches(key,'all')),
					("business-unit-details":jobBusinessUnitDetails::getJobBusinessUnitDetails(jobInfo.businessUnitNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.business-unit-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-details.business-unit-details'],key)),
					("flsaStatus": jobInfo.flsaStatusNav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.flsaStatusNav') or isKeyMatches(key,'job-details.flsaStatusNav.externalCode') or isKeyMatches(key,'all')),
					("union-worker-details":{
						("choice-details":{
							("is-union-worker":jobInfo.customString51Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.union-worker-details') or isKeyMatches(key,'job-details.union-worker-details.choice-details') or isKeyMatches(key,'job-details.union-worker-details.choice-details.is-union-worker') or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.union-worker-details') or isKeyMatches(key,'job-details.union-worker-details.choice-details')  or isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.union-worker-details') or isKeyMatches(key,'all')),
					("pay-group-details": jobPayGroupDetails::getJobPayGroupDetails(jobInfo.payGroupNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.pay-group-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['pay-group-details'],key)),
					("grade-details": {
						("choice-details": {
							("grade": jobInfo.customString2Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.grade-details') or isKeyMatches(key,'job-details.grade-details.choice-details') or isKeyMatches(key,'job-details.grade-details.choice-details.grade') or  isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.grade-details') or isKeyMatches(key,'job-details.grade-details.choice-details') or  isKeyMatches(key,'all'))
						
					}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.grade-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['grade-details','grade-details.choice-details'],key)),
					("position-details": jobPositionDetails::getJobPositionDetails(jobInfo.positionNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['position-details'],key)),
					("job-sub-function-details": jobSubFunctionDetails::getJobSubFunctionDetails(jobInfo.customString5Nav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-sub-function-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-sub-function-details'],key)),
					("job-code-details": jobCodeDetails::getJobCodeDetails(jobInfo.jobCodeNav,key)) if(isJobCodeMatches(key) or checkIfKeyConsistsChildEntities(['job-code-details'],key)),
					("department-details": departmentDetails::getDepartmentDetails(jobInfo.departmentNav,key)) if(isDepartmentDetailsMatches(key) or checkIfKeyConsistsChildEntities(['department-details'],key)),	
					("location-details": locationDetails::getLocationDetails(jobInfo.locationNav,key)) if(isLocationDetailsMatches(key) or checkIfKeyConsistsChildEntities(['location-details'],key)),	
					("manager-details": managerDetails::getManagerDetails(jobInfo.managerUserNav,key)) if(isManagerDetailsMatches(key) or checkIfKeyConsistsChildEntities(['manager-details'],key)),
					("management-level-details": {
						("choice-details": {
							("management-level": jobInfo.customString8Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.management-level-details.choice-details') or isKeyMatches(key,'job-details.management-level-details.choice-details.grade') or  isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.management-level-details') or isKeyMatches(key,'job-details.management-level-details.choice-details') or  isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.management-level-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['management-level-details','management-level-details.choice-details'],key)),
					("personal-management-level-details": {
						("choice-details": {
							("personal-management-level": jobInfo.customString15Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.personal-management-level-details.choice-details') or isKeyMatches(key,'job-details.personal-management-level-details.choice-details.grade') or  isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.personal-management-level-details') or isKeyMatches(key,'job-details.personal-management-level-details.choice-details') or  isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.personal-management-level-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['personal-management-level-details','personal-management-level-details.choice-details'],key)),
					("cost-center-details": jobCostCenterDetails::getJobCostCenterDetails(jobInfo.costCenterNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.cost-center-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['cost-center-details'],key)),
					("job-function-details": jobFunctionDetails::getJobFunctionDetails(jobInfo.customString4Nav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-function-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-function-details'],key)),
					("employee-type-details": jobEmployeeTypeDetails::getJobEmployeeTypeDetails(jobInfo.employeeClassNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.employee-type-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['employee-type-details','employee-type-details.choice-details'],key)),
					("employee-status-details": jobEmployeeStatusDetails::getJobEmployeeStatusDetails(jobInfo.emplStatusNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.employee-status-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['employee-status-details'],key)),
					("event-details": jobEventDetails::getJobEventDetails(jobInfo.eventNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['event-details','event-details.choice-details'],key)),
					("event-reason-details": jobEventReasonDetails::getJobEventReasonDetails(jobInfo.eventReasonNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.event-reason-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['event-reason-details'],key)),
					("company-details": jobCompanyDetails::getJobCompanyDetails(jobInfo.companyNav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.company-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['company-details'],key)),
					("contractor-type-details": jobContractorTypeDetails::getJobContractorTypeDtls(jobInfo.customString27Nav,key)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.contractor-type-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-details.contractor-type-details'],key)),
					("previous-rb-job-details": {
						("choice-details": {
							("is-previous-rb-employee": jobInfo.customString30Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.previous-rb-job-details.choice-details') or isKeyMatches(key,'job-details.previous-rb-job-details.choice-details.is-previous-rb-employee') or  isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.previous-rb-job-details') or isKeyMatches(key,'job-details.previous-rb-job-details.choice-details') or  isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.previous-rb-job-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['previous-rb-job-details','previous-rb-job-details.choice-details'],key)),
					("manager-employee-details": empManagerEmploymentDetails::getManagerEmpDetails(jobInfo.managerEmploymentNav,key)) if(isKeyMatches(key,'job-details.manager-employee-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-details.manager-employee-details'],key)),
					("benefit-program-details":{
						("external-code": jobInfo.customString57Nav.externalCode) if(isKeyMatches(key,'job-details.benefit-program-details.external-code') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
						("choice-details": {
							("benefit-program": jobInfo.customString57Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.benefit-program-details.choice-details.benefit-program') or isKeyMatches(key,'all') or isKeyMatches(key,'root'))
						}) if(isKeyMatches(key,'job-details.benefit-program-details') or isKeyMatches(key,'job-details.benefit-program-details.choice-details') or  isKeyMatches(key,'all'))
					})if(isKeyMatches(key,'job-details.benefit-program-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-details.benefit-program-details','job-details.benefit-program-details.choice-details'],key)),
					("ifcn-flag-details":{
						("external-code": jobInfo.customString35Nav.externalCode) if(isKeyMatches(key,'job-details.ifcn-flag-details.external-code') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
						("choice-details": {
							("ifcb-flag": jobInfo.customString35Nav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.ifcn-flag-details.choice-details.ifcn-flag') or isKeyMatches(key,'all') or isKeyMatches(key,'root'))
						}) if(isKeyMatches(key,'job-details.ifcn-flag-details') or isKeyMatches(key,'job-details.ifcn-flag-details.choice-details') or  isKeyMatches(key,'all'))
					})if(isKeyMatches(key,'job-details.ifcn-flag-details') or  isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['job-details.ifcn-flag-details','job-details.ifcn-flag-details.choice-details'],key))	
			})}			
		else []
	) 