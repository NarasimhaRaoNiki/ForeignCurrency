%dw 2.0
//GLOBAL FUNCTIONS
fun convertSQLDateformat(dateString) =( dateString replace " " with "T" )
fun convertSFDate(vSFDate)  =
  (if(vSFDate != null) convertSQLDateformat(( using (formattedDate = (vSFDate replace /\+.*$/ with '') replace /[^0-9-]/ with '')
  	(formattedDate as Number / 1000) as DateTime) as String {format : "yyyy-MM-dd HH:mm:ss.SSS"}) else null)
  	
