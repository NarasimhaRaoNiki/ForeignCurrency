%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobEventDetails(vJobEventDetailsNav,key)=
(
	if(vJobEventDetailsNav != null)
	{
		("external-code": vJobEventDetailsNav.externalCode) if(isKeyMatches(key,'job-details.event-details') or isKeyMatches(key,'job-details.event-details.external-code') or  isKeyMatches(key,'all')),
						("choice-details": {
							("event-description": vJobEventDetailsNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.event-details') or isKeyMatches(key,'job-details.event-details.choice-details') or isKeyMatches(key,'job-details.event-details.choice-details.event-description') or  isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'job-details.event-details') or isKeyMatches(key,'job-details.event-details.choice-details') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)