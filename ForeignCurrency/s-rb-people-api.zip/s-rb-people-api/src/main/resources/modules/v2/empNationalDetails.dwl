%dw 2.0
import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

fun getEmpNationalDetails(vEmpNationalDetails,key) = 
	(
		if(vEmpNationalDetails != null) 
			{
				"nationalDetails": vEmpNationalDetails.results default [] map ((nationalNav , indexOfResult) -> {
					
					("national-id": nationalNav.nationalId) if(isKeyMatches(key,'person-details.national-details.national-id') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("country": nationalNav.country) if(isKeyMatches(key,'person-details.national-details.country') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("cardType": nationalNav.cardType) if(isKeyMatches(key,'person-details.national-details.cardType') or isKeyMatches(key,'all') or isKeyMatches(key,'root'))
					
				})
			}
		else []
	) 