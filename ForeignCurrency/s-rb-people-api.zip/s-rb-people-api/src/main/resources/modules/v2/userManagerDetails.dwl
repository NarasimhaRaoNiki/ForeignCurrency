%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::userManagerEmpDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserManagerDetails(vUserManagerDetails,key)=
(
	if(vUserManagerDetails != null)
	{
		("first-name": vUserManagerDetails.firstName) if(isKeyMatches(key,'user-details.manager-details') or isKeyMatches(key,'user-details.manager-details.first-name') or isKeyMatches(key,'all')),
		("last-name": vUserManagerDetails.lastName) if(isKeyMatches(key,'user-details.manager-details') or isKeyMatches(key,'user-details.manager-details.last-name') or isKeyMatches(key,'all')),
		("default-full-name": vUserManagerDetails.defaultFullName) if(isKeyMatches(key,'user-details.manager-details') or isKeyMatches(key,'user-details.manager-details.default-full-name') or isKeyMatches(key,'all')),
		("employee-details": userManagerEmpDetails::getUserMngrEmpDetails(vUserManagerDetails.empInfo,key)) if(isKeyMatches(key,'user-details.manager-details') or isKeyMatches(key,'user-details.manager-details.employee-details') or isKeyMatches(key,'all'))
	}
	else null
	
)