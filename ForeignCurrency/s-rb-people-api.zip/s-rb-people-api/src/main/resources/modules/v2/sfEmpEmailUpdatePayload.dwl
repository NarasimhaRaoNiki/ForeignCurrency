%dw 2.0
output application/json

var vEmailType = payload.'employee-details'.'person-details'.'email-details'.'email-type'
var vPersonIdExternal=payload.'employee-details'.'person-details'.'email-details'.'person-id-external'
---
{
	"__metadata": {
		uri: "PerEmail(emailType='" ++ vEmailType ++"',personIdExternal='" ++ vPersonIdExternal ++ "')"
	},
	personIdExternal: vPersonIdExternal,
	emailType: vEmailType,
	isPrimary: payload.'employee-details'.'person-details'.'email-details'.'is-primary',
	emailAddress: payload.'employee-details'.'person-details'.'email-details'.'email-address'
}