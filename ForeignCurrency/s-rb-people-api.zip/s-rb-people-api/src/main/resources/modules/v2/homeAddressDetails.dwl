%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getHomeAddressDetails(vPersonHomeAddressDetails,key) = 
	(
		if(vPersonHomeAddressDetails != null) 
			{
				"homeAddressDetails": vPersonHomeAddressDetails.results default [] map ((result , indexOfResult) -> {
					("address-type": result.addressType) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.addressType') or isKeyMatches(key,'all')),
					("start-date": commonDWFunctions::convertSFDate(result.startDate)) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.start-date') or isKeyMatches(key,'all')),
					("county": result.county) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.county') or isKeyMatches(key,'all')),
					("province": result.province) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.province') or isKeyMatches(key,'all')),
					("state": result.state) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.state') or isKeyMatches(key,'all')),
					("zip-code": result.zipCode) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.zip-code') or isKeyMatches(key,'all')),
					("address1": result.address1) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.address1') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(result.endDate)) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.end-date') or isKeyMatches(key,'all')),
					("address2": result.address2) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.address2') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(result.lastModifiedDateTime)) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("state-details": {
						("external-code": result.stateNav.externalCode) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.state-details') or isKeyMatches(key,'person-details.address-details.state-details.external-code') or isKeyMatches(key,'all'))
					} ) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.state-details') or isKeyMatches(key,'all')),
					("country": result.country) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.country') or isKeyMatches(key,'all')),
					("city": result.city) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'person-details.address-details.city') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 