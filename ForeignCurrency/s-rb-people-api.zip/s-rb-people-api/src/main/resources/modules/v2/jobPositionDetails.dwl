%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobPositionDetails(vJobPositionDetailsNav,key)=
(
	if(vJobPositionDetailsNav != null)
	{
		("job-title": vJobPositionDetailsNav.jobTitle) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or isKeyMatches(key,'job-details.position-details.job-title') or  isKeyMatches(key,'all')),
		("effective-start-date": commonDWFunctions::convertSFDate(vJobPositionDetailsNav.effectiveStartDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or isKeyMatches(key,'job-details.position-details.effective-start-date') or  isKeyMatches(key,'all')),
		("effective-end-date": commonDWFunctions::convertSFDate(vJobPositionDetailsNav.effectiveEndDate)) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or isKeyMatches(key,'job-details.position-details.effective-end-date') or  isKeyMatches(key,'all')),
		("effective-status": vJobPositionDetailsNav.effectiveStatus) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or isKeyMatches(key,'job-details.position-details.effective-status') or  isKeyMatches(key,'all')),
		("is-email-account-required": vJobPositionDetailsNav.cust_ADacc) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.position-details') or isKeyMatches(key,'job-details.position-details.is-email-account-required') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)