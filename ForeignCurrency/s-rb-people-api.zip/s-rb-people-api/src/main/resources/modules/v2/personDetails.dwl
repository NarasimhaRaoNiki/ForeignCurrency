%dw 2.0

import * from dw::core::Arrays

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{"check":parent some (key as String contains $)})).check find true) !=0) true else false

import modules::v2::commonDWFunctions
import modules::v2::personalDetailsMapping
import modules::v2::homeAddressDetails
import modules::v2::phoneDetails
import modules::v2::emailDetails
import modules::v2::empNationalDetails

var personalDetailsSubEntities=['personal-details','personal-details.marital-status-details','personal-details.salutation-details']
var personPhondeDetailsSubEntities=['person-details.phone-details','person-details.phone-details.phone-type-details','person-details.phone-details.phone-type-details.choice-details','person-details.phone-details.country-code-details','person-details.phone-details.country-code-details.choice-details']
var personEmailDetailsSubEntities=['person-details.email-details','person-details.email-details.email-type-details','person-details.email-details.email-type-details.choice-details']
//GLOBAL FUNCTIONS
fun getPersonDetails(vEmpPersonNavDetails,key) = 
	(
		if(vEmpPersonNavDetails != null) 
			{
				("network-id": vEmpPersonNavDetails."customString1") if(isKeyMatches(key,'person-details') or isKeyMatches(key,'person-details.network-id') or isKeyMatches(key,'all')),
  				("person-id-external": vEmpPersonNavDetails.personIdExternal) if(isKeyMatches(key,'person-details') or isKeyMatches(key,'person-details.person-id-external') or isKeyMatches(key,'all')),
				("date-of-birth": commonDWFunctions::convertSFDate(vEmpPersonNavDetails.dateOfBirth)) if(isKeyMatches(key,'person-details') or isKeyMatches(key,'person-details.date-of-birth') or isKeyMatches(key,'all')),
				
				("personal-details": personalDetailsMapping::getPersonalDetails(vEmpPersonNavDetails.personalInfoNav,key).personalDetailsObj) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(personalDetailsSubEntities,key)),
				("address-details": homeAddressDetails::getHomeAddressDetails(vEmpPersonNavDetails.homeAddressNavDEFLT,key).homeAddressDetails) if(isKeyMatches(key,'person-details.address-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['person-details.address-details','person-details.address-details.state-details'],key)),
				("phone-details": phoneDetails::getPhoneDetails(vEmpPersonNavDetails.phoneNav,key).phoneDetails default []) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'person-details.phone-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(personPhondeDetailsSubEntities,key)),
				("email-details": emailDetails::getEmailDetails(vEmpPersonNavDetails.emailNav,key).emailDetails default []) if(isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(personEmailDetailsSubEntities,key)),
				("national-details":empNationalDetails::getEmpNationalDetails(vEmpPersonNavDetails.nationalIdNav,key).nationalDetails default []) if(isKeyMatches(key,'person-details.national-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['person-details.national-details'],key))
				
			}
		else null
	) 