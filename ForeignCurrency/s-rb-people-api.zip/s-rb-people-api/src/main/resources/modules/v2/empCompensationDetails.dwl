%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::empPayCompRecurringDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpCompensationDetails(vEmpCompDetails,key) = 
	(
		if(vEmpCompDetails != null) 
			{
				"compDetails": vEmpCompDetails.results default [] map ((compNav , indexOfResult) -> {
					("payroll-id": compNav.payrollId) if(isKeyMatches(key,'compensation-details.payroll-id') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("payType": compNav.payTypeNav.externalCode) if(isKeyMatches(key,'compensation-details.payTypeNav') or isKeyMatches(key,'compensation-details.payTypeNav.externalCode') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("emp-pay-comp-recurring-details": empPayCompRecurringDetails::getEmpPayCompRecurrDetails(compNav.empPayCompRecurringNav,key).payCompRecurDetails) if(isKeyMatches(key,'compensation-details.emp-pay-comp-recurring-details') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 