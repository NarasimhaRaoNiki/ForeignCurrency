%dw 2.0
output application/json

import * from dw::core::Arrays

var select =  if((attributes.queryParams.select splitBy(",") default [])[0] == "") [] else (attributes.queryParams.select splitBy(",") default [])
var expand =  if((attributes.queryParams.expand splitBy(",") default [])[0] == "") [] else (attributes.queryParams.expand splitBy(",") default [])
var vKey = [] 

fun isParamInExpand(expand,entity) = expand some (entity contains $)

// get common entities in select and expand query params
var getCommonEntities= if(sizeOf(select)!=0) (select map ((param,index)->{
  						(expand map ((entity,index)->{
							("check": entity) if((entity startsWith(param)) and (param contains "-details."))
						  }))
						})) else []

//remove common entities in expand
var finalExpand = if (getCommonEntities.*check !=null) ((expand map ((ent,index)->{
						"entity":ent,
						"condition":sizeOf(getCommonEntities.*check find ent),
				  		("expand":if(sizeOf(getCommonEntities.*check find ent) !=0 ) "" else ent) if(isEmpty(if(sizeOf(getCommonEntities.*check find ent) !=0 ) "" else ent)== false)
				  })).*expand) else null

---
if(sizeOf(select)!=0 and sizeOf(expand) !=0 and finalExpand != null) select ++ finalExpand
else if (sizeOf(select)!=0 and sizeOf(expand) !=0 and finalExpand == null and getCommonEntities.*check != null) select
else if (sizeOf(select)!=0 and sizeOf(expand) !=0 and finalExpand == null and getCommonEntities.*check == null) select ++ expand
else if(sizeOf(select)!=0 and sizeOf(expand) !=0 and finalExpand == null) select ++ expand
else if (sizeOf(select)==0 and sizeOf(expand)!=0) expand + "root"
else if (sizeOf(select) !=0 and sizeOf(expand) ==0) select
else if (sizeOf(select) ==0 and sizeOf(expand) ==0) ["all"]
else ["all"]










