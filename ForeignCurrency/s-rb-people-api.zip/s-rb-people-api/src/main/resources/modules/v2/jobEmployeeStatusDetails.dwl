%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobEmployeeStatusDetails(vJobEmployeeStatusDetails,key)=
(
	if(vJobEmployeeStatusDetails != null)
	{
		("external-code": vJobEmployeeStatusDetails.externalCode) if(isKeyMatches(key,'job-details.employee-status-details') or isKeyMatches(key,'job-details.employee-status-details.external-code') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)