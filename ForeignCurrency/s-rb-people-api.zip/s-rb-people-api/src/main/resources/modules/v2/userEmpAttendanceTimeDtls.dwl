%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserEmpAttendanceTimeDtls(vUserEmpAttTimeDtls,key) = 
	(
		if(vUserEmpAttTimeDtls != null ) 
			{
				"empAttendanceTimeDtls": vUserEmpAttTimeDtls.results default [] map ((userIdOfEmployeeTimeNav , indexOfResult) -> {
					
					("approval-status": userIdOfEmployeeTimeNav.approvalStatus) if(isKeyMatches(key,'employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details.approval-status') or isKeyMatches(key,'all')),
					("actual-return-date": commonDWFunctions::convertSFDate(userIdOfEmployeeTimeNav.loaActualReturnDate)) if(isKeyMatches(key,'employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details.actual-return-date') or isKeyMatches(key,'all')),
					("expected-return-date": commonDWFunctions::convertSFDate(userIdOfEmployeeTimeNav.loaExpectedReturnDate)) if(isKeyMatches(key,'employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details.expected-return-date') or isKeyMatches(key,'all')),
					("start-date": commonDWFunctions::convertSFDate(userIdOfEmployeeTimeNav.startDate)) if(isKeyMatches(key,'employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details.start-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(userIdOfEmployeeTimeNav.endDate)) if(isKeyMatches(key,'employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'user-details.employee-attendance-time-details.end-date') or isKeyMatches(key,'all'))
				})
			}
		else []
	) 