%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getAddressDetails(vAddressDetails,key) = 
	(
		if(vAddressDetails != null) 
			{
				
				("county": vAddressDetails.county) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.county') or isKeyMatches(key,'all')),
				("zip-code": vAddressDetails.zipCode) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.zip-code') or isKeyMatches(key,'all')),
				("address1": vAddressDetails.address1) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.address1') or isKeyMatches(key,'all')),
				("address2": vAddressDetails.address2) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.address2') or isKeyMatches(key,'all')),
				("address3": vAddressDetails.address3) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.address3') or isKeyMatches(key,'all')),
				("city": vAddressDetails.city) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.city') or isKeyMatches(key,'all')),
				("country": vAddressDetails.country) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.country') or isKeyMatches(key,'all')),
				("last-modified-date-time": commonDWFunctions::convertSFDate(vAddressDetails.lastModifiedDateTime)) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.last-modified-date-time') or isKeyMatches(key,'all')),
				("state-details": {
					("choice-details": {
						("state": vAddressDetails.stateNav.picklistLabels.results[0].label) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.state-details') or isKeyMatches(key,'job-details.location-details.address-details.state-details.choice-details.state') or isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.state-details') or isKeyMatches(key,'job-details.location-details.address-details.state-details.choice-details')  or isKeyMatches(key,'all'))
				} ) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.state-details') or isKeyMatches(key,'all')),
				("county-details": {
					("choice-details": {
						("county": vAddressDetails.countyNav.picklistLabels.results[0].label) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.county-details') or isKeyMatches(key,'job-details.location-details.address-details.county-details.choice-details.county') or isKeyMatches(key,'all'))
					}) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.county-details') or isKeyMatches(key,'job-details.location-details.address-details.county-details.choice-details') or isKeyMatches(key,'all'))
				} ) if(isKeyMatches(key,'location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.county-details') or isKeyMatches(key,'all'))
			}
		else null
	) 