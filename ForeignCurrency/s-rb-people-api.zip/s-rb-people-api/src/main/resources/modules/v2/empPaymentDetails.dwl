%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::empPaymentBankDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpPaymentDetails(vEmpPaymentDetails,key) = 
	(
		if(vEmpPaymentDetails != null) 
			{
				"paymentDetails": vEmpPaymentDetails.results default [] map ((paymentNav , indexOfResult) -> {
					("bank-details": empPaymentBankDetails::getEmpPayBankDetails(paymentNav.toPaymentInformationDetailV3,key).bankDetail) if(isKeyMatches(key,'payment-details.bank-details') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 
 