%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::empJobRelationshipTypeDetails
import modules::v2::empJobRelationshipUserDetails

fun isKeyMatches(arr,key)= (if (sizeOf(arr find key) !=0) true else false)



fun getEmpJobRelationshipDtls(vEmpJobRelationshipDtls,key) = 
	(
		if(vEmpJobRelationshipDtls != null) 
			{
				"empJobRelationshipDtls": vEmpJobRelationshipDtls.results default [] map ((empJobRelationshipNav , indexOfResult) -> {
					("start-date": commonDWFunctions::convertSFDate(empJobRelationshipNav.startDate)) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.start-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(empJobRelationshipNav.endDate)) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.end-date') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(empJobRelationshipNav.lastModifiedDateTime)) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("relationship-type-details": empJobRelationshipTypeDetails::getEmpJobRelationshipTypeDetails(empJobRelationshipNav.relationshipTypeNav,key)) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-type-details') or isKeyMatches(key,'all')),
					("relationship-user-details": empJobRelationshipUserDetails::getEmpJobRelationshipUserDetails(empJobRelationshipNav.relUserNav,key)) if(isKeyMatches(key,'emp-job-relationship-details') or isKeyMatches(key,'emp-job-relationship-details.relationship-user-details') or isKeyMatches(key,'all'))
				})
			}
		else []
	) 