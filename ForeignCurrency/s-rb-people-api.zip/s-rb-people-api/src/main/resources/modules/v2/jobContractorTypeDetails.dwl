%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobContractorTypeDtls(vJobContractorTypeNav,key)=
(
	if(vJobContractorTypeNav != null)
	{
		("external-code": vJobContractorTypeNav.externalCode) if(isKeyMatches(key,'job-details.contractor-type-details') or isKeyMatches(key,'job-details.contractor-type-details.external-code') or  isKeyMatches(key,'all')),
		("choice-details": {
			("contractor-type": vJobContractorTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.contractor-type-details') or isKeyMatches(key,'job-details.contractor-type-details.choice-details') or isKeyMatches(key,'job-details.contractor-type-details.choice-details.contractor-type') or  isKeyMatches(key,'all'))
		}) if(isKeyMatches(key,'job-details.contractor-type-details') or isKeyMatches(key,'job-details.contractor-type-details.choice-details') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)