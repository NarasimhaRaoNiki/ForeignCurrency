%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobSubFunctionDetails(vJobSubFunctionDetailsNav,key)=
(
	if(vJobSubFunctionDetailsNav != null)
	{
		("external-code": vJobSubFunctionDetailsNav.externalCode) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-sub-function-details') or isKeyMatches(key,'job-details.job-sub-function-details.external-code') or  isKeyMatches(key,'all')),
		("external-name": vJobSubFunctionDetailsNav.externalName) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.job-sub-function-details') or isKeyMatches(key,'job-details.job-sub-function-details.external-name') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)