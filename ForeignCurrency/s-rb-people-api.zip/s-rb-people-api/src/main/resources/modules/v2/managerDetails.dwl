%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::jobMngrEmpInfoDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getManagerDetails(vManagerDetails,key) = 
	(
		if(vManagerDetails != null) 
			{
				//("manager-id": vManagerDetails.userId) if(isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.manager-id') or isKeyMatches(key,'all')),
				("first-name": vManagerDetails.firstName) if(isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.first-name') or isKeyMatches(key,'all')),
				("last-name": vManagerDetails.lastName) if(isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.last-name') or isKeyMatches(key,'all')),
				("default-full-name": vManagerDetails.defaultFullName) if(isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.default-full-name') or isKeyMatches(key,'all')),
				("employee-details": jobMngrEmpInfoDetails::getJobMngrEmpDetails(vManagerDetails.empInfo,key)) if(isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.employee-details') or isKeyMatches(key,'all'))
			}
		else null
	) 