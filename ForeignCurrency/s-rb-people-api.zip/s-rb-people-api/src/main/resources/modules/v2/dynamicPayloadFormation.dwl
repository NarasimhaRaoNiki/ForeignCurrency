%dw 2.0
import * from dw::core::Objects


fun checkElementExistance(object,element)=if(sizeOf((object map ((key,index) ->{
											"check":key  contains(element)
												})).check find true) !=0) true else false
fun parsePayload(empObject)=
(
	if(empObject != null)
	{
		(if(checkElementExistance(keySet(empObject),'person-details'))
		(
			
		("person-details":{
			("person-id-external":empObject."person-details"."person-id-external")
				if(checkElementExistance(keySet(empObject."person-details"),'person-id-external')),
			("network-id":empObject."person-details"."network-id")
			if(checkElementExistance(keySet(empObject."person-details"),'network-id')),
			("email-details":{
				("person-id-external": empObject."person-details"."email-details"."person-id-external")
				if(checkElementExistance(keySet(empObject."person-details"."email-details"),'person-id-external')),
					("email-type":(if(empObject."person-details"."email-details"."email-type" == p('secure::email.type.business'))
									{
										"email-type": p('secure::email.type.business.id')
									}
									else
									{
										"email-type":  p('secure::email.type.personal.id')
									}
					)."email-type") if(checkElementExistance(keySet(empObject."person-details"."email-details"),'person-id-external') and checkElementExistance(keySet(empObject."person-details"."email-details"),'email-address')),
					("is-primary":empObject."person-details"."email-details"."is-primary") if(checkElementExistance(keySet(empObject."person-details"."email-details"),'person-id-external') and checkElementExistance(keySet(empObject."person-details"."email-details"),'email-address')),
					("email-address": empObject."person-details"."email-details"."email-address")
				if(checkElementExistance(keySet(empObject."person-details"."email-details"),'email-address'))
				
			}) if(checkElementExistance(keySet(empObject."person-details"),'email-details'))
		}) if(checkElementExistance(keySet(empObject),'person-details'))
	)
	else (
				("user-details":{
					
					("user-id":empObject."user-details"."user-id")if(checkElementExistance(keySet(empObject."user-details"),'user-id') and checkElementExistance(keySet(empObject."user-details"),'username')),
					("username":empObject."user-details"."username")if(checkElementExistance(keySet(empObject."user-details"),'user-id') and checkElementExistance(keySet(empObject."user-details"),'username'))
				}) if(checkElementExistance(keySet(empObject),'user-details'))
			)			
		)
	
	}
	else
	{
		
	}
)
output application/json
---
{ 
	"employee-details" : parsePayload(payload."employee-details")
	
	
}