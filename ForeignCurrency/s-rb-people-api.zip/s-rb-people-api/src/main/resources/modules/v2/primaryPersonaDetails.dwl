%dw 2.0

import * from dw::core::Arrays

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false
												
									
//GLOBAL FUNCTIONS - get persona details
fun getPersonaDetails(vEmpPersonaDetails,key) = 
	(
		if(vEmpPersonaDetails != null) 
			{
				"personaDetailsObj": {
	
						("primary-persona-details":{
							("primary-persona-name": vEmpPersonaDetails.picklistLabels.results[0].label) if(isKeyMatches(key,'persona-details') or isKeyMatches(key,'persona-details.primary-persona-details') or  isKeyMatches(key,'persona-details.primary-persona-details.primary-persona-name') or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'persona-details.primary-persona-details')  or isKeyMatches(key,'all'))
				
				}
				
			}			
		else null
	) 