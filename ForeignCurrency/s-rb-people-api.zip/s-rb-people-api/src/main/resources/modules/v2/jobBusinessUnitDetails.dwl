%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobBusinessUnitDetails(vJobBusinessUnitDetailsNav,key)=
(
	if(vJobBusinessUnitDetailsNav != null)
	{
		("description":vJobBusinessUnitDetailsNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.business-unit-details') or isKeyMatches(key,'job-details.business-unit-details.description') or isKeyMatches(key,'all'))
		
	}
	else null
	
)