%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::jobLocationAddressDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getLocationDetails(vLocationDetails,key) = 
	(
		if(vLocationDetails != null) 
			{
				("name": vLocationDetails.name) if (isKeyMatches(key,'location-details') or isKeyMatches(key,'job-details.location-details') or isKeyMatches(key,'job-details.location-details.name') or isKeyMatches(key,'all')),
				("external-code": vLocationDetails.externalCode) if (isKeyMatches(key,'location-details') or isKeyMatches(key,'job-details.location-details') or isKeyMatches(key,'job-details.location-details.external-code') or isKeyMatches(key,'all')),
				("description": vLocationDetails.description) if (isKeyMatches(key,'location-details') or isKeyMatches(key,'job-details.location-details') or isKeyMatches(key,'job-details.location-details.description') or isKeyMatches(key,'all')),
				("address-details": jobLocationAddressDetails::getAddressDetails(vLocationDetails.addressNavDEFLT,key)) if (isKeyMatches(key,'job-details.location-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'all'))
			}
		else null
	)
