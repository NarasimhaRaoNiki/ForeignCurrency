%dw 2.0
output application/json
---
{ 
  "acknowledgment": {
    "message-id": vars.vLogVars.messageId,
    "status": p('secure::s.status.error'),
    "description": p('secure::error.description'),
    "errors": [
      {
        "error-code": p('secure::http.400'),
        "error-description": p('secure::http.400.message')
      }
    ]
  }
}
