%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobFunctionDetails(vJobFunctionDetailsNav,key)=
(
	if(vJobFunctionDetailsNav != null)
	{
		("description": vJobFunctionDetailsNav.description) if(isKeyMatches(key,'job-details.job-function-details') or isKeyMatches(key,'job-details.job-function-details.description') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)