import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getSeveranceDetails(vEmpSevDetails,key) = 
	(
		if(vEmpSevDetails != null) 
			{
				("external-code": vEmpSevDetails.externalCode) if(isKeyMatches(key,'severance-details.external-code')  or isKeyMatches(key,'all'))	
			}
		else null
	) 