%dw 2.0
output application/json
---
//Canonical Field : Success Factor Field
{
	//employee entity fields
	"person-id-external": "personIdExternal",
	"user-id": "userId",
	"start-date":"startDate",
	"end-date":"endDate",
	"payroll-end-date":"payrollEndDate",
	"last-date-worked":"lastDateWorked",
	"benefits-eligibility-start-date":"benefitsEligibilityStartDate",
	"bonus-pay-expiration-date":"bonusPayExpirationDate",
	"rb-user-name":"customString2",
	"last-modified-date-time":"lastModifiedDateTime",
	"is-contingent-worker" :"isContingentWorker",
	"original-start-date":	"originalStartDate",
	
	//Nav entity mappings
	"job-details":"jobInfoNav",
	"person-details":"personNav",
	"user-details":"userNav",
	"emp-job-relationship-details": "empJobRelationshipNav",
	
	//customString2Nav
	"persona-details": "customString2Nav",	
	"persona-details.primary-persona-details": "customString2Nav/picklistLabels",
	"persona-details.primary-persona-details.primary-persona-name" : "customString2Nav/picklistLabels/label",
	
	//PersonNav entity mappings
	"person-details.personal-details": "personNav/personalInfoNav",
	"person-details.personal-details.marital-status-details": "personNav/personalInfoNav/maritalStatusNav",
	"person-details.personal-details.marital-status-details.choice-details": "personNav/personalInfoNav/maritalStatusNav/picklistLabels",
	"person-details.personal-details.salutation-details": "personNav/personalInfoNav/salutationNav",
	"person-details.personal-details.salutation-details.choice-details": "personNav/personalInfoNav/salutationNav/picklistLabels",
	"person-details.address-details": "personNav/homeAddressNavDEFLT",
	"person-details.address-details.state-details": "personNav/homeAddressNavDEFLT/stateNav",
	"person-details.phone-details": "personNav/phoneNav",
	"person-details.phone-details.phone-type-details": "personNav/phoneNav/phoneTypeNav",
	"person-details.phone-details.phone-type-details.choice-details": "personNav/phoneNav/phoneTypeNav/picklistLabels",	
	"person-details.phone-details.country-code-details":"personNav/phoneNav/countryCodeNav",
	"person-details.phone-details.country-code-details.choice-details": "personNav/phoneNav/countryCodeNav/picklistLabels",
	"person-details.email-details": "personNav/emailNav",
	"person-details.email-details.email-type-details": "personNav/emailNav/emailTypeNav",
	"person-details.email-details.email-type-details.choice-details": "personNav/emailNav/emailTypeNav/picklistLabels",
	
		
	//JobInfoNav entity mappings
	"job-details.pay-group-details": "jobInfoNav/payGroupNav",
	"job-details.grade-details": "jobInfoNav/customString2Nav",
	"job-details.grade-details.choice-details": "jobInfoNav/customString2Nav/picklistLabels",
	"job-details.position-details":"jobInfoNav/positionNav",
	"job-details.job-sub-function-details": "jobInfoNav/customString5Nav",
	"job-details.job-code-details": "jobInfoNav/jobCodeNav",
	"job-details.job-code-details.job-code-description-details":"jobInfoNav/jobCodeNav/regularTemporaryNav",
	"job-details.department-details": "jobInfoNav/departmentNav",
	"job-details.location-details": "jobInfoNav/locationNav",
	"job-details.location-details.address-details": "jobInfoNav/locationNav/addressNavDEFLT",
	"job-details.location-details.address-details.county-details": "jobInfoNav/locationNav/addressNavDEFLT/countyNav",
	"job-details.location-details.address-details.county-details.choice-details": "jobInfoNav/locationNav/addressNavDEFLT/countyNav/picklistLabels",
	"job-details.location-details.address-details.state-details": "jobInfoNav/locationNav/addressNavDEFLT/stateNav",
	"job-details.location-details.address-details.state-details.choice-details": "jobInfoNav/locationNav/addressNavDEFLT/stateNav/picklistLabels",
	"job-details.management-level-details": "jobInfoNav/customString8Nav",
	"job-details.management-level-details.choice-details": "jobInfoNav/customString8Nav/picklistLabels",
	"job-details.personal-management-level-details": "jobInfoNav/customString15Nav",
	"job-details.personal-management-level-details.choice-details": "jobInfoNav/customString15Nav/picklistLabels",
	"job-details.manager-details": "jobInfoNav/managerUserNav",
	"job-details.manager-details.employee-details": "jobInfoNav/managerUserNav/empInfo",
	"job-details.manager-details.employee-details.person-details": "jobInfoNav/managerUserNav/empInfo/personNav",
	"job-details.manager-details.employee-details.job-details": "jobInfoNav/managerUserNav/empInfo/jobInfoNav",
	"job-details.manager-details.employee-details.job-details.position-details": "jobInfoNav/managerUserNav/empInfo/jobInfoNav/positionNav",
	"job-details.cost-center-details": "jobInfoNav/costCenterNav",
	"job-details.job-function-details": "jobInfoNav/customString4Nav",
	"job-details.employee-type-details": "jobInfoNav/employeeClassNav",
	"job-details.employee-type-details.choice-details": "jobInfoNav/employeeClassNav/picklistLabels",
	"job-details.employee-status-details": "jobInfoNav/emplStatusNav/picklistLabels",
	"job-details.employee-status-code-details": "jobInfoNav/emplStatusNav",
	"job-details.employee-lob-details" : "jobInfoNav/customString39Nav/picklistLabels",
	"job-details.employee-lob-code-details" : "jobInfoNav/customString39Nav",
	
	"job-details.event-details": "jobInfoNav/eventNav",
	"job-details.event-details.choice-details": "jobInfoNav/eventNav/picklistLabels",
	"job-details.event-reason-details": "jobInfoNav/eventReasonNav",
	"job-details.company-details": "jobInfoNav/companyNav",
	"job-details.previous-rb-job-details": "jobInfoNav/customString30Nav",
	"job-details.previous-rb-job-details.choice-details": "jobInfoNav/customString30Nav/picklistLabels",
	"job-details.division-details":"jobInfoNav/divisionNav",
	"job-details.hr-status-details.choice-details":"jobInfoNav/customString19Nav/picklistLabels",
	"job-details.union-worker-details":"jobInfoNav/customString51Nav",
	"job-details.union-worker-details.choice-details":"jobInfoNav/customString51Nav/picklistLabels",
	"job-details.contractor-type-details":"jobInfoNav/customString27Nav",
	"job-details.contractor-type-details.choice-details":"jobInfoNav/customString27Nav/picklistLabels",
	"job-details.business-unit-details":"jobInfoNav/businessUnitNav",
	"job-details.manager-details.employee-details.person-details.email-details":"jobInfoNav/managerUserNav/empInfo/personNav/emailNav",
	"job-details.manager-details.employee-details.person-details.email-details.email-type-details": "jobInfoNav/managerUserNav/empInfo/personNav/emailNav/emailTypeNav",
	"job-details.manager-details.employee-details.person-details.email-details.email-type-details.choice-details":"jobInfoNav/managerUserNav/empInfo/personNav/emailNav/emailTypeNav/picklistLabels",
	//UserNav entity mappings
	"user-details.employee-attendance-time-details": "userNav/userIdOfEmployeeTimeNav",
	"user-details.manager-details": "userNav/manager",
	"user-details.manager-details.employee-details": "userNav/manager/empInfo",
	//userNav/teamMembersSize
	"user-details.team-members-size": "userNav/teamMembersSize",
	
	"user-details.manager-details.employee-details.user-id": "userNav/manager/empInfo/userId",
	"user-details.manager-details.employee-details.person-id-external": "userNav/manager/empInfo/personIdExternal",
	
	"user-details.manager-details.employee-details.job-details":"userNav/manager/empInfo/jobInfoNav",
	"user-details.manager-details.employee-details.job-details.position-details":"userNav/manager/empInfo/jobInfoNav/positionNav",
	"user-details.manager-details.employee-details.person-details": "userNav/manager/empInfo/personNav",
	"user-details.work-order-details": "userNav/userSysIdOfWorkOrderNav",
	
	//empJobRelationshipNav entity mappings
	"emp-job-relationship-details.relationship-type-details": "empJobRelationshipNav/relationshipTypeNav",
	"emp-job-relationship-details.relationship-user-details": "empJobRelationshipNav/relUserNav",
		
	//jobInfoNav fields mapping
	"job-details.start-date":"jobInfoNav/startDate",
	"job-details.job-seq-no":"jobInfoNav/seqNumber",
	"job-details.job-entry-date":"jobInfoNav/jobEntryDate",
	"job-details.end-date":"jobInfoNav/endDate",
	"job-details.position-entry-date":"jobInfoNav/positionEntryDate",
	"job-details.contract-end-date":"jobInfoNav/contractEndDate",
	"job-details.fte":"jobInfoNav/fte",
	"job-details.created-date-time":"jobInfoNav/createdDateTime",	
	"job-details.country-of-company":"jobInfoNav/countryOfCompany",	
	"job-details.is-fulltime-employee":"jobInfoNav/isFulltimeEmployee",	
	"job-details.location":"jobInfoNav/location",
	"job-details.is-shift-employee":"jobInfoNav/isShiftEmployee",
	"job-details.department":"jobInfoNav/department",
	"job-details.working-days-per-week":"jobInfoNav/workingDaysPerWeek",
	"job-details.pay-group":"jobInfoNav/payGroup",
	"job-details.cost-center":"jobInfoNav/costCenter",
	"job-details.termination-date":"jobInfoNav/terminationDate",
	"job-details.company":"jobInfoNav/company",
	"job-details.is-cross-border-worker":"jobInfoNav/isCrossBorderWorker",
	"job-details.pay-grade":"jobInfoNav/payGrade",
	"job-details.standard-hours":"jobInfoNav/standardHours",
	"job-details.job-title":"jobInfoNav/jobTitle",
	"job-details.job-code":"jobInfoNav/jobCode",
	"job-details.regulatory-region":"jobInfoNav/customString6",
	"job-details.regulatory-region-full-code-details":"jobInfoNav/customString6Nav",
	"job-details.regulatory-region-full":"jobInfoNav/customString6Nav/externalName_defaultValue",
	"job-details.hr-status":"jobInfoNav/customString19Nav/picklistLabels/label",
	"job-details.last-modified-on": "jobInfoNav/lastModifiedOn",
	"job-details.position":"jobInfoNav/position",
	"job-details.work-location":"jobInfoNav/workLocation",
	"job-details.business-unit":"jobInfoNav/businessUnit",
	"job-details.job-function":"jobInfoNav/customString4",
	"job-details.region":"jobInfoNav/customString33",
	"job-details.employee-region-details":"jobInfoNav/customString33Nav",
	"job-details.employee-region":"jobInfoNav/customString33Nav/externalName",
	"job-details.employee-status":"jobInfoNav/emplStatusNav/picklistLabels/label",
	"job-details.event" :"jobInfoNav/event",
	"job-details.event-reason":"jobInfoNav/eventReason",
	"job-details.business-title":"jobInfoNav/customString28",
	"job-details.employee-type":"jobInfoNav/employeeClass",
	"job-details.manager-id": "jobInfoNav/managerId",
	"job-details.last-modified-date-time":"jobInfoNav/lastModifiedDateTime",
	"job-details.division":"jobInfoNav/division",
	"job-details.division-details.description":"jobInfoNav/divisionNav/description",
	"job-details.last-modified-by":"jobInfoNav/lastModifiedBy",
	//"job-details.timezone":"jobInfoNav/timezone",
	"job-details.employee-lob" : "jobInfoNav/customString39Nav/picklistLabels/label",
	
	//Job-Details.contractorType-Details entity mapping
	"job-details.contractor-type-details.external-code":"jobInfoNav/customString27Nav/externalCode",
	
	//Job-Details.contractorType-Details.Picklist entity mapping
	"job-details.contractor-type-details.choice-details.contractor-type":"jobInfoNav/customString27Nav/picklistLabels/label",
	
	//Job-Details.payGroupNav detailed field mapping
	"job-details.pay-group-details.description": "jobInfoNav/payGroupNav/description",
	
	//Job-details.customString2Nav(gradeDetails).PickListLables detailed field mapping
	"job-details.grade-details.choice-details.grade":"jobInfoNav/customString2Nav/picklistLabels/label",
	
	//Job-Details.positionNav detailed field mapping
	"job-details.position-details.job-title":"jobInfoNav/positionNav/jobTitle",	
	"job-details.position-details.effective-start-date": "jobInfoNav/positionNav/effectiveStartDate",
	"job-details.position-details.effective-end-date": "jobInfoNav/positionNav/effectiveEndDate",
	"job-details.position-details.effective-status": "jobInfoNav/positionNav/effectiveStatus",
	
	"job-details.position-details.is-email-account-required": "jobInfoNav/positionNav/cust_ADacc",
	
	//Job-Dtails.customString5Nav(job-sub-function-details) detailed field mapping
	"job-details.job-sub-function-details.external-code": "jobInfoNav/customString5Nav/externalCode",
	"job-details.job-sub-function-details.external-name":"jobInfoNav/customString5Nav/externalName",
	//Job-Details.jobCodeNav(job code details) field mapping
	"job-details.job-code-details.job-code": "jobInfoNav/jobCodeNav/regularTemporary",
	"job-details.job-code-details.job-code-description": "jobInfoNav/jobCodeNav/regularTemporaryNav/label_defaultValue",
	"job-details.job-code-details.description": "jobInfoNav/jobCodeNav/description",
	"job-details.job-code-details.is-regular": "jobInfoNav/jobCodeNav/isRegular",
	"job-details.job-code-details.is-fulltime-employee" :"jobInfoNav/jobCodeNav/isFulltimeEmployee",
	"job-details.job-code-details.last-modified-date-time":"jobInfoNav/jobCodeNav/lastModifiedDateTime",
	
	//Job-Details.department-details field mapping
	"job-details.department-details.description" :"jobInfoNav/payGroupNav/description",
	
	//Job-Details.LocationNav detailed field mapping
	"job-details.location-details.name":"jobInfoNav/locationNav/name",
	"job-details.location-details.external-code": "jobInfoNav/locationNav/externalCode",
	"job-details.location-details.description":"jobInfoNav/locationNav/description",
	
	//Job-Details.LocationNav.AddressNav field mapping
	"job-details.location-details.address-details.county":"jobInfoNav/locationNav/addressNavDEFLT/county",
	"job-details.location-details.address-details.zip-code":"jobInfoNav/locationNav/addressNavDEFLT/zipCode",
	"job-details.location-details.address-details.address1":"jobInfoNav/locationNav/addressNavDEFLT/address1",
	"job-details.location-details.address-details.address2":"jobInfoNav/locationNav/addressNavDEFLT/address2",
	"job-details.location-details.address-details.address3":"jobInfoNav/locationNav/addressNavDEFLT/address3",
	"job-details.location-details.address-details.city":"jobInfoNav/locationNav/addressNavDEFLT/city",
	"job-details.location-details.address-details.country":"jobInfoNav/locationNav/addressNavDEFLT/country",
	"job-details.location-details.address-details.last-modified-date-time":"jobInfoNav/locationNav/addressNavDEFLT/lastModifiedDateTime",
	//Job-Details.LocationNav.AddressNav.CountyNav.PicklistLables field mapping
	"job-details.location-details.address-details.county-details.choice-details.county":"jobInfoNav/locationNav/addressNavDEFLT/countyNav/picklistLabels/label",
	//Job-Details.LocationNav.AddressNav.stateNav.PicklistLables field mapping
	"job-details.location-details.address-details.state-details.choice-details.state": "jobInfoNav/locationNav/addressNavDEFLT/stateNav/picklistLabels/label",
	
	//Job-Details.customString8Nav(management-level-details).picklistLables field mapping
	"job-details.management-level-details.choice-details.management-level": "jobInfoNav/customString8Nav/picklistLabels/label",
	
	//Job-Details.customString15Nav(management-level-details).picklistLables field mapping
	"job-details.personal-management-level-details.choice-details.personal-management-level": "jobInfoNav/customString15Nav/picklistLabels/label",
	
	//Job-Details.manager-details field mapping
	"job-details.manager-details.manager-id":"jobInfoNav/managerUserNav/userId",
	"job-details.manager-details.first-name": "jobInfoNav/managerUserNav/firstName",
	"job-details.manager-details.last-name": "jobInfoNav/managerUserNav/lastName",
	"job-details.manager-details.default-full-name":"jobInfoNav/managerUserNav/defaultFullName",
	
	//Job-Details.manager-details.empInfoDetails field mapping
	"job-details.manager-details.employee-details.user-id": "jobInfoNav/managerUserNav/empInfo/userId",
	"job-details.manager-details.employee-details.person-id-external": "jobInfoNav/managerUserNav/empInfo/personIdExternal",
	//Job-Details.manager-details.empInfoDetails.personDetails field mapping
	"job-details.manager-details.employee-details.person-details.network-id":"jobInfoNav/managerUserNav/empInfo/personNav/customString1",
	
	//Job-Details.manager-details.empInfoDetails.jobInfoDetails field mapping
	"job-details.manager-details.employee-details.job-details.position":"jobInfoNav/managerUserNav/empInfo/jobInfoNav/positionNav/jobTitle",
	"job-details.manager-details.employee-details.job-details.country-of-company": "jobInfoNav/managerUserNav/empInfo/jobInfoNav/countryOfCompany",
	
	//Job-Details.manager-details.empInfoDetails.personInfoDetails.Email mapping
	"job-details.manager-details.employee-details.person-details.email-details.email-address":"jobInfoNav/managerUserNav/empInfo/personNav/emailNav/emailAddress",
	"job-details.manager-details.employee-details.person-details.email-details.email-type-details.choice-details.email-type": "jobInfoNav/managerUserNav/empInfo/personNav/emailNav/emailTypeNav/picklistLabels/label",
	
	//Job_details.cost-center-details field mapping
	"job-details.cost-center-details.description": "jobInfoNav/costCenterNav/description",
	
	//Job-Details.customString4Nav(job-function-details) field mapping
	"job-details.job-function-details.description":"jobInfoNav/customString4Nav/description",
	
	//Job-Details.employeeClassNav(employee-type-details) field mapping
	"job-details.employee-type-details.external-code": "jobInfoNav/employeeClassNav/externalCode",
	//Job-Details.employeeClassNav(employee-type-details).picklistLables field mapping
	"job-details.employee-type-details.choice-details.description": "jobInfoNav/employeeClassNav/picklistLabels/label",
	
	//Job-details.empStatusNav field mapping
	"job-details.employee-status-details.external-code":"jobInfoNav/emplStatusNav/externalCode",
	
	//Job-Details.event-details field mapping
	"job-details.event-details.external-code": "jobInfoNav/eventNav/externalCode",
	//Job-Details.event-details.picklistLables field mapping
	"job-details.event-details.choice-details.event-description":"jobInfoNav/eventNav/picklistLabels/label",
	
	//Job-Details.event-reason-details field mapping
	"job-details.event-reason-details.name" : "jobInfoNav/eventReasonNav/name",
	"job-details.event-reason-details.external-code": "jobInfoNav/eventReasonNav/externalCode",
	
	//Job-Details.company-details field mapping
	"job-details.company-details.description" : "jobInfoNav/companyNav/description",
	
	//Job-Details.customString30Nav.picklistLables filed mapping
	"job-details.previous-rb-job-details.choice-details.is-previous-rb-employee": "jobInfoNav/customString30Nav/picklistLabels/label",
	
	//Job-Details.customString51Nav(Union-worker-details).pcklistLabels field mapping
	"job-details.union-worker-details.choice-details.is-union-worker":"jobInfoNav/customString51Nav/picklistLabels/label",
	
	//job-details.business-unit-details enityt field mapping
	"job-details.business-unit-details.description":"jobInfoNav/businessUnitNav/description",
	
	//person details fields
	"person-details.network-id":"personNav/customString1",
	"person-details.person-id-external":"personNav/personIdExternal",
	"person-details.date-of-birth":"personNav/dateOfBirth",
		
	//Person-Details.personal details field mapping
	"person-details.personal-details.start-date":"personNav/personalInfoNav/startDate",
	//"person-details.personal-details.date-of-birth":"personNav/personalInfoNav/dateOfBirth",
	"person-details.personal-details.date-of-death":"personNav/personalInfoNav/dateOfDeath",
	"person-details.personal-details.challenge-status":"personNav/personalInfoNav/challengeStatus",
	"person-details.personal-details.gender":"personNav/personalInfoNav/gender",
	"person-details.personal-details.first-name":"personNav/personalInfoNav/firstName",
	"person-details.personal-details.last-name":"personNav/personalInfoNav/lastName",
	"person-details.personal-details.preferred-name":"personNav/personalInfoNav/preferredName",
	"person-details.personal-details.middle-name":"personNav/personalInfoNav/middleName",
	"person-details.personal-details.birth-name":"personNav/personalInfoNav/birthName",
	"person-details.personal-details.formal-name":"personNav/personalInfoNav/formalName",
	"person-details.personal-details.third-name":"personNav/personalInfoNav/thirdName",
	"person-details.personal-details.end-date":"personNav/personalInfoNav/endDate",
	"person-details.personal-details.last-modified-date-time":"personNav/personalInfoNav/lastModifiedDateTime",
	//Person-details.personal-details.maritalStatusNav.picklistLables field mapping
	"person-details.personal-details.marital-status-details.choice-details.marital-status": "personNav/personalInfoNav/maritalStatusNav/picklistLabels/label",
	//Person-details.personal-details.salutationNav.picklistLables field mapping
	"person-details.personal-details.salutation-details.choice-details.salutation": "personNav/personalInfoNav/salutationNav/picklistLabels/label",
	
	//Person-Details.home address details field mapping
	"person-details.address-details.start-date":"personNav/homeAddressNavDEFLT/startDate",
	"person-details.address-details.address-type":"personNav/homeAddressNavDEFLT/addressType",
	"person-details.address-details.county": "personNav/homeAddressNavDEFLT/county",
	"person-details.address-details.zip-code":"personNav/homeAddressNavDEFLT/zipCode",
	"person-details.address-details.address1":"personNav/homeAddressNavDEFLT/address1",
	"person-details.address-details.end-date":"personNav/homeAddressNavDEFLT/endDate",
	"person-details.address-details.address2":"personNav/homeAddressNavDEFLT/address2",
	"person-details.address-details.last-modified-date-time":"personNav/homeAddressNavDEFLT/lastModifiedDateTime",
	"person-details.address-details.city":"personNav/homeAddressNavDEFLT/city",
	"person-details.address-details.country":"personNav/homeAddressNavDEFLT/country",
	
	//Person-Details.homeAddressDetails.StateNav field mapping
	"person-details.address-details.state-details.external-code":"personNav/homeAddressNavDEFLT/stateNav/externalCode",
	
	//Person-Details.phone details field mapping
	"person-details.phone-details.phone-number":"personNav/phoneNav/phoneNumber",
	"person-details.phone-details.last-modified-date-time":"personNav/phoneNav/lastModifiedDateTime",
	//Person-Details.PhoneNav.PhoneTypeNav.picklistLables filed mapping
	"person-details.phone-details.phone-type-details.choice-details.phone-type": "personNav/phoneNav/phoneTypeNav/picklistLabels/label",
	//Person-Details.PhoneNav.countryCodeNav.picklistLables filed mapping
	"person-details.phone-details.country-code-details.choice-details.country-code":"personNav/phoneNav/countryCodeNav/picklistLabels/label",
	
	
	//Person-Details.emailNav field mapping
	"person-details.email-details.email-address":"personNav/emailNav/emailAddress",
	"person-details.email-details.is-primary":"personNav/emailNav/isPrimary",
	"person-details.email-details.person-id-external": "personNav/emailNav/personIdExternal",
	"person-details.email-details.last-modified-date-time":"personNav/emailNav/lastModifiedDateTime",
	"person-details.email-details.created-on":"personNav/emailNav/createdOn" ,
	//Person-Details.emailNav.emailTypeNav.picklistLables field mapping
	"person-details.email-details.email-type-details.choice-details.email-type": "personNav/emailNav/emailTypeNav/picklistLabels/label",
	
	//user details field mapping
	"user-details.user-id":"userNav/userId",
	"user-details.username": "userNav/username",
	"user-details.emp-id":"userNav/empId",
	"user-details.status":"userNav/status",
	"user-details.last-modified-date-time":"userNav/lastModifiedDateTime",	
	//UserDetails.Manager-details field mapping
	"user-details.manager-details.default-full-name": "userNav/manager/defaultFullName",
	"user-details.manager-details.first-name": "userNav/manager/firstName",
	"user-details.manager-details.last-name": "userNav/manager/lastName",
	//UserDetails.Manager-details.empInfo.jobInfoNAV field mapping
	"user-details.manager-details.employee-details.job-details.position": "userNav/manager/empInfo/jobInfoNav/positionNav/jobTitle",
	//UserDetails.Manager-details.empInfo.personNav field mapping
	"user-details.manager-details.employee-details.person-details.network-id": "userNav/manager/empInfo/personNav/customString1",
	
	//UserDetails.employee-attendance-time-details filed mapping
	"user-details.employee-attendance-time-details.approval-status": "userNav/userIdOfEmployeeTimeNav/approvalStatus",
	"user-details.employee-attendance-time-details.actual-return-date": "userNav/userIdOfEmployeeTimeNav/loaActualReturnDate",
	"user-details.employee-attendance-time-details.expected-return-date": "userNav/userIdOfEmployeeTimeNav/loaExpectedReturnDate",
	"user-details.employee-attendance-time-details.start-date": "userNav/userIdOfEmployeeTimeNav/startDate",
	"user-details.employee-attendance-time-details.end-date": "userNav/userIdOfEmployeeTimeNav/endDate",
	
	//UserDetails.work-order-details filed mapping
	"user-details.work-order-details.work-order-id": "userNav/userSysIdOfWorkOrderNav/workOrderId",
	"user-details.work-order-details.start-date": "userNav/userSysIdOfWorkOrderNav/startDate",
	"user-details.work-order-details.end-date": "userNav/userSysIdOfWorkOrderNav/endDate",
	
	
	//emp-job-relationship-details field mapping
	"emp-job-relationship-details.start-date": "empJobRelationshipNav/startDate",
	"emp-job-relationship-details.end-date": "empJobRelationshipNav/endDate",
	"emp-job-relationship-details.last-modified-date-time": "empJobRelationshipNav/lastModifiedDateTime",
	//emp-job-relationship-details.relationship-type-details field mapping
	"emp-job-relationship-details.relationship-type-details.external-code": "empJobRelationshipNav/relationshipTypeNav/externalCode",
	//emp-job-relationship-details.relationship-user-details field mapping
	"emp-job-relationship-details.relationship-user-details.default-full-name": "empJobRelationshipNav/relUserNav/defaultFullName"
	
	
	
	
}