%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobEventReasonDetails(vJobEventReasonDetailsNav,key)=
(
	if(vJobEventReasonDetailsNav != null)
	{
		("name": vJobEventReasonDetailsNav.name) if(isKeyMatches(key,'job-details.event-reason-details') or isKeyMatches(key,'job-details.event-reason-details.name') or  isKeyMatches(key,'all')),
		("external-code": vJobEventReasonDetailsNav.externalCode) if(isKeyMatches(key,'job-details.event-reason-details') or isKeyMatches(key,'job-details.event-reason-details.external-code') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)