%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobCompanyDetails(vJobCompanyDetails,key)=
(
	if(vJobCompanyDetails != null)
	{
		("description": vJobCompanyDetails.description) if(isKeyMatches(key,'job-details.company-details') or isKeyMatches(key,'job-details.company-details.description') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)