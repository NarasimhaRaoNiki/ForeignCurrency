%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserMngrEmpDetails(vUserMngrEmpDtls,key)=
(
	if(vUserMngrEmpDtls != null)
	{
			("user-id": vUserMngrEmpDtls.userId) if(isKeyMatches(key,'user-details.manager-details.employee-details') or isKeyMatches(key,'user-details.manager-details.employee-details.user-id') or isKeyMatches(key,'all')),
			("person-id-external": vUserMngrEmpDtls.personIdExternal) if(isKeyMatches(key,'user-details.manager-details.employee-details') or isKeyMatches(key,'user-details.manager-details.employee-details.person-id-external') or isKeyMatches(key,'all')),
			("job-details": getUserMngrEmpJobDetails(vUserMngrEmpDtls.jobInfoNav,key).jobDetailsEntity) if(isKeyMatches(key,'user-details.manager-details.employee-details.job-details') or isKeyMatches(key,'all')),
			("person-details": {
				("network-id": vUserMngrEmpDtls.personNav.customString1) if(isKeyMatches(key,'user-details.manager-details.employee-details.person-details') or isKeyMatches(key,'user-details.manager-details.employee-details.person-details.network-id') or isKeyMatches(key,'all'))
			}) if(isKeyMatches(key,'user-details.manager-details.employee-details.person-details') or isKeyMatches(key,'all'))
		
	}
	else null
)

fun getUserMngrEmpJobDetails(vUserMngrEmpJobDtls,key)=
(
	if(vUserMngrEmpJobDtls != null and sizeOf(vUserMngrEmpJobDtls.results)>0)
	{
		("jobDetailsEntity": [{
				("position": vUserMngrEmpJobDtls.results[0].positionNav.jobTitle) if(isKeyMatches(key,'user-details.manager-details.employee-details.job-details') or isKeyMatches(key,'user-details.manager-details.employee-details.job-details.position') or isKeyMatches(key,'all'))
			}])
	}
	else
	{
		("jobDetailsEntity": [])
	}
)