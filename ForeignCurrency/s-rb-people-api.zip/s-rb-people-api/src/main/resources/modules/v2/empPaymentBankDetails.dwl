%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpPayBankDetails(vEmpPayBankDetails,key) = 
	(
		if(vEmpPayBankDetails != null) 
			{
				"bankDetail": vEmpPayBankDetails.results default [] map ((payEmpBankDetailsNav , indexOfResult) -> {
					("routing-number": payEmpBankDetailsNav.routingNumber) if(isKeyMatches(key,'payment-details.bank-details.routing-number') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("iban": payEmpBankDetailsNav.iban) if(isKeyMatches(key,'payment-details.bank-details.iban') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("payment-type": payEmpBankDetailsNav.payType) if(isKeyMatches(key,'payment-details.bank-details.payment-type') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("account-number": payEmpBankDetailsNav.accountNumber) if(isKeyMatches(key,'payment-details.bank-details.account-number') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("bic": payEmpBankDetailsNav.businessIdentifierCode) if(isKeyMatches(key,'payment-details.bank-details.bic') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("bank-name": payEmpBankDetailsNav.cust_BankName) if(isKeyMatches(key,'payment-details.bank-details.bank-name') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("branch-name": payEmpBankDetailsNav.bankNav.bankBranch) if(isKeyMatches(key,'payment-details.bank-details.branch-name') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("bank-city": payEmpBankDetailsNav.bankNav.city) if(isKeyMatches(key,'payment-details.bank-details.bank-city') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("account-owner": payEmpBankDetailsNav.accountOwner) if(isKeyMatches(key,'payment-details.bank-details.account-owner') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("country": payEmpBankDetailsNav.bankCountryNav.results[0].twoCharCountryCode) if(isKeyMatches(key,'payment-details.bank-details.country-details.country') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("currency-code": payEmpBankDetailsNav.currencyNav.results[0].code) if(isKeyMatches(key,'payment-details.bank-details.currency-code') or isKeyMatches(key,'all') or isKeyMatches(key,'root'))
				})
			}
		else null
	) 