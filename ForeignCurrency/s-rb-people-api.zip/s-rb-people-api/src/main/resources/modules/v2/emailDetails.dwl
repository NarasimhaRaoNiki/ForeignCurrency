%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getEmailDetails(vEmailDetails,key) = 
	(
		if(vEmailDetails != null) 
			{
				"emailDetails": vEmailDetails.results default [] map ((emailNav , indexOfResult) -> {
					("is-primary": emailNav.isPrimary) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.is-primary') or isKeyMatches(key,'all')),
					("person-id-external": emailNav.personIdExternal) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.person-id-external') or isKeyMatches(key,'all')),
					("email-address": emailNav.emailAddress) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-address') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(emailNav.lastModifiedDateTime)) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("email-type-details": {
						("choice-details": {
							("email-type": emailNav.emailTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-type-details') or isKeyMatches(key,'person-details.email-details.email-type-details.choice-details') or isKeyMatches(key,'all'))
						}) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-type-details') or isKeyMatches(key,'person-details.email-details.email-type-details.choice-details') or isKeyMatches(key,'person-details.email-details.email-type-details.choice-details.email-type') or isKeyMatches(key,'all'))
					} ) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-type-details') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 