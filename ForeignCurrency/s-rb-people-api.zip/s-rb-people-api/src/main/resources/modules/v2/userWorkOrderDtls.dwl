%dw 2.0

import modules::v2::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserWorkOrderDtls(vUserWorkOrderDtls,key) = 
	(
		if(vUserWorkOrderDtls != null) 
			{
				"userWorkOrderDtls": vUserWorkOrderDtls.results default [] map ((userSysIdOfWorkOrderNav , indexOfResult) -> {
					
					("work-order-id": userSysIdOfWorkOrderNav.workOrderId) if(isKeyMatches(key,'user-details.work-order-details') or isKeyMatches(key,'user-details.work-order-details') or isKeyMatches(key,'user-details.work-order-details.work-order-id') or isKeyMatches(key,'all')),
					("start-date": commonDWFunctions::convertSFDate(userSysIdOfWorkOrderNav.startDate)) if(isKeyMatches(key,'work-order-details') or isKeyMatches(key,'user-details.work-order-details') or isKeyMatches(key,'user-details.work-order-details.start-date') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(userSysIdOfWorkOrderNav.endDate)) if(isKeyMatches(key,'work-order-details') or isKeyMatches(key,'user-details.work-order-details') or isKeyMatches(key,'user-details.work-order-details.end-date') or isKeyMatches(key,'all'))
				})
			}
		else []
	) 