%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getJobEmployeeTypeDetails(vJobEmployeeTypeDetails,key)=
(
	if(vJobEmployeeTypeDetails != null)
	{
		("external-code": vJobEmployeeTypeDetails.externalCode) if(isKeyMatches(key,'job-details.employee-type-details') or isKeyMatches(key,'job-details.employee-type-details.external-code') or  isKeyMatches(key,'all')),
		("choice-details": {
			("description": vJobEmployeeTypeDetails.picklistLabels.results[0].label) if(isKeyMatches(key,'job-details.employee-type-details') or isKeyMatches(key,'job-details.employee-type-details.choice-details') or isKeyMatches(key,'job-details.employee-type-details.choice-details.description') or  isKeyMatches(key,'all'))
		}) if(isKeyMatches(key,'job-details.employee-type-details') or isKeyMatches(key,'job-details.employee-type-details.choice-details') or  isKeyMatches(key,'all'))
		
	}
	else null
	
)