%dw 2.0

output application/json

import * from dw::core::Arrays

import modules::v2::commonDWFunctions
import modules::v2::userDetails
import modules::v2::jobDetails
import modules::v2::personDetails
import modules::v2::empJobRelationshipDetails
import modules::v2::primaryPersonaDetails


var jobDetailsSubEntities=['job-details','job-details.job-code-details','job-details.department-details','job-details.manager-details','job-details.location-details','job-details.pay-group-details','job-details.grade-details','job-details.position-details','job-details.job-sub-function-details','job-details.management-level-details','job-details.cost-center-details','job-details.job-function-details','job-details.employee-type-details','job-details.employee-status-details','job-details.even-details','job-details.event-reason-details','job-details.job-details.company-details','job-details.previous-rb-job-details','all']
var personDetailsSubEntities= ['person-details','person-details.personal-details','person-details.address-details','person-details.phone-details','person-details.email-details','all']
var personaDetailsSubEntities=['persona-details','persona-details.primary-persona-details','all']

var token = if (isEmpty(payload.d."__next")) "" else (((payload.d."__next" splitBy ("skiptoken="))[1] splitBy("&"))[0])


fun checkIsJobMatches(arr)= if(isKeyMatches(arr,'job-details') or isKeyMatches(arr,'job-details.job-code-details') or isKeyMatches(arr,'job-details.location-details')	or isKeyMatches(arr,'job-details.pay-group-details')	or isKeyMatches(arr,'job-details.grade-details') or isKeyMatches(arr,'job-details.position-details') or isKeyMatches(arr,'job-details.job-sub-function-details') or isKeyMatches(arr,'job-details.department-details') or isKeyMatches(arr,'job-details.management-level-details') or isKeyMatches(arr,'job-details.manager-details') or isKeyMatches(arr,'job-details.cost-center-details') or isKeyMatches(arr,'job-details.job-function-details') or isKeyMatches(arr,'job-details.employee-type-details') or isKeyMatches(arr,'job-details.employee-status-details') or isKeyMatches(arr,'job-details.event-details')	or isKeyMatches(arr,'job-details.event-reason-details') or isKeyMatches(arr,'job-details.company-details') or isKeyMatches(arr,'job-details.previous-rb-job-details') or isKeyMatches(arr,'all'))
							true else false
fun checkIsPersonaMatches(arr)= if(isKeyMatches(arr,'persona-details') or isKeyMatches(arr,'persona-details.primary-persona-details') or isKeyMatches(arr,'all'))
							true else false

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false
							
fun checkIspersonDetailsMatches(arr) = if(isKeyMatches(arr,'person-details') or isKeyMatches(arr,'person-details.personal-details') or isKeyMatches(arr,'person-details.address-details') or isKeyMatches(arr,'person-details.phone-details') or isKeyMatches(arr,'person-details.email-details') or isKeyMatches(arr,'all'))
										true else false
										
										
var getNextUrlQueryParams = (if(isEmpty(attributes.queryParams.select) == false) ("select="++ attributes.queryParams.select ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.filter) == false) ("filter="++ attributes.queryParams.filter ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.expand) == false) ("expand="++ attributes.queryParams.expand ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.orderby) == false) ("orderby="++ attributes.queryParams.orderby ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.limit) == false) ("limit="++ attributes.queryParams.limit ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.leap) == false) ("leap="++ attributes.queryParams.leap ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.paging) == false) ("paging="++ attributes.queryParams.paging ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.pagesize) == false) ("pagesize="++ attributes.queryParams.pagesize ++ "&") else "") ++
                      if(isEmpty(token) == false)("skiptoken="++ token) else ""

---

{
	"acknowledgment": {
		"message-id": correlationId,
    	"status": "Success",
    	"next-batch-token":token
    },
	"employee-details": payload.d.results default [] map ((emp , indexOfEmp) -> {
		("start-date": commonDWFunctions::convertSFDate(emp.startDate)) if( isKeyMatches(vars.vSelect,'start-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("end-date": commonDWFunctions::convertSFDate(emp.endDate)) if( isKeyMatches(vars.vSelect,'end-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("payroll-end-date": commonDWFunctions::convertSFDate(emp.payrollEndDate)) if(isKeyMatches(vars.vSelect,'payroll-end-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
	    ("last-date-worked": commonDWFunctions::convertSFDate(emp.lastDateWorked)) if(isKeyMatches(vars.vSelect,'last-date-worked') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("benefits-eligibility-start-date": commonDWFunctions::convertSFDate(emp.benefitsEligibilityStartDate)) if(isKeyMatches(vars.vSelect,'benefits-eligibility-start-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("bonus-pay-expiration-date": commonDWFunctions::convertSFDate(emp.bonusPayExpirationDate)) if(isKeyMatches(vars.vSelect,'bonus-pay-expiration-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("rb-user-name": emp.customString2) if(isKeyMatches(vars.vSelect,'rb-user-name') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("last-modified-date-time": commonDWFunctions::convertSFDate(emp.lastModifiedDateTime)) if(isKeyMatches(vars.vSelect,'last-modified-date-time')  or isKeyMatches(vars.vSelect,'all')),
		("user-id": emp.userId) if(isKeyMatches(vars.vSelect,'user-id') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("person-id-external": emp.personIdExternal) if(isKeyMatches(vars.vSelect,'person-id-external') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),	
		("is-contingent-worker": emp.isContingentWorker) if(isKeyMatches(vars.vSelect,'is-contingent-worker') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("original-start-date": commonDWFunctions::convertSFDate(emp.originalStartDate)) if(isKeyMatches(vars.vSelect,'original-start-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("job-details": jobDetails::getJobDetails(emp.jobInfoNav,vars.vSelect).jobDetailsObj) if(checkIsJobMatches(vars.vSelect) or checkIfKeyConsistsChildEntities(jobDetailsSubEntities,vars.vSelect)),
		("person-details": personDetails::getPersonDetails(emp.personNav,vars.vSelect)) if(checkIspersonDetailsMatches(vars.vSelect) or checkIfKeyConsistsChildEntities(personDetailsSubEntities,vars.vSelect)),
		("user-details": userDetails::getUserDetails(emp.userNav,vars.vSelect)) if(isKeyMatches(vars.vSelect,'user-details') or isKeyMatches(vars.vSelect,'user-details.manager-details') or isKeyMatches(vars.vSelect,'user-details.employee-attendance-time-details') or isKeyMatches(vars.vSelect,'user-details.work-order-details') or isKeyMatches(vars.vSelect,'all') or checkIfKeyConsistsChildEntities(['user-details','user-details.manager-details','user-details.employee-attendance-time-details','user-details.work-order-details'],vars.vSelect)),
		("emp-job-relationship-details": empJobRelationshipDetails::getEmpJobRelationshipDtls(emp.empJobRelationshipNav,vars.vSelect).empJobRelationshipDtls) if(isKeyMatches(vars.vSelect,'emp-job-relationship-details') or isKeyMatches(vars.vSelect,'emp-job-relationship-details.relationship-type-details') or isKeyMatches(vars.vSelect,'emp-job-relationship-details.relationship-user-details')  or isKeyMatches(vars.vSelect,'all') or checkIfKeyConsistsChildEntities(['emp-job-relationship-details','relationship-user-details','relationship-type-details'],vars.vSelect)),
		("persona-details": primaryPersonaDetails::getPersonaDetails(emp.customString2Nav,vars.vSelect).personaDetailsObj default []) if(checkIsPersonaMatches(vars.vSelect) or checkIfKeyConsistsChildEntities(personaDetailsSubEntities,vars.vSelect)) 
		})
}