%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getJobDivisionDetails(vJobDivisionDetailsNav,key)=
(
	if(vJobDivisionDetailsNav != null)
	{
		("description":vJobDivisionDetailsNav.description) if(isKeyMatches(key,'job-details') or isKeyMatches(key,'job-details.division-details') or isKeyMatches(key,'job-details.division-details.description') or isKeyMatches(key,'all'))
		
	}
	else null
	
)