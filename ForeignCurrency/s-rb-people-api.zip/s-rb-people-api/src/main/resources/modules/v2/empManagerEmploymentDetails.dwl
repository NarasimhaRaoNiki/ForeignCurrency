%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getManagerEmpDetails(vManagerEmpDetails,key) = 
	(
		if(vManagerEmpDetails != null) 
			{
				
				("person-id-external": vManagerEmpDetails.personIdExternal) if(isKeyMatches(key,'root') or isKeyMatches(key,'job-details.manager-employee-details.person-id-external') or isKeyMatches(key,'all')),
				
			}
		else null
	) 