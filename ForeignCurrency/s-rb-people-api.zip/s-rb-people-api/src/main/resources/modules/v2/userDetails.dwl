%dw 2.0

import modules::v2::commonDWFunctions
import modules::v2::userManagerDetails
import modules::v2::userEmpAttendanceTimeDtls
import modules::v2::userWorkOrderDtls

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getUserDetails(vUserDetails,key) = 
	(
		if(vUserDetails != null) 
			{
				("user-id": vUserDetails.userId) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.user-id') or isKeyMatches(key,'all')),
				("username": vUserDetails.username) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.username') or isKeyMatches(key,'all')),
				("emp-id": vUserDetails.empId) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.emp-id') or isKeyMatches(key,'all')),
				("status": vUserDetails.status) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.status') or isKeyMatches(key,'all')),
				("team-members-size": vUserDetails.teamMembersSize) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.team-members-size') or isKeyMatches(key,'all')),
				("last-modified-date-time":commonDWFunctions::convertSFDate(vUserDetails.lastModifiedDateTime)) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.last-modified-date-time') or isKeyMatches(key,'all')),
				("manager-details": userManagerDetails::getUserManagerDetails(vUserDetails.manager,key)) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.manager-details') or isKeyMatches(key,'all')),
				("employee-attendance-time-details": userEmpAttendanceTimeDtls::getUserEmpAttendanceTimeDtls(vUserDetails.userIdOfEmployeeTimeNav,key).empAttendanceTimeDtls) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.employee-attendance-time-details') or isKeyMatches(key,'all')),
				("work-order-details": userWorkOrderDtls::getUserWorkOrderDtls(vUserDetails.userSysIdOfWorkOrderNav,key).userWorkOrderDtls) if(isKeyMatches(key,'user-details') or isKeyMatches(key,'user-details.work-order-details') or isKeyMatches(key,'all'))
			}
		else null
	) 