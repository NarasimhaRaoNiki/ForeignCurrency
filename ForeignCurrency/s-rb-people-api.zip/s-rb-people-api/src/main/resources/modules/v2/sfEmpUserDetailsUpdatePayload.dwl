%dw 2.0
output application/json
---
{
	"__metadata": {
		uri: "User('" ++ payload.'employee-details'.'user-details'.'user-id' ++ "')"
	},
	userId: payload.'employee-details'.'user-details'.'user-id',
	username: payload.'employee-details'.'user-details'.'username'
	
}