%dw 2.0
output application/json
---
{
	"__metadata": {
		uri: "PerPerson('" ++ payload.'employee-details'.'person-details'.'person-id-external' ++ "')"
	},
	personIdExternal: payload.'employee-details'.'person-details'.'person-id-external',
	customString1: payload.'employee-details'.'person-details'.'network-id'
	
}