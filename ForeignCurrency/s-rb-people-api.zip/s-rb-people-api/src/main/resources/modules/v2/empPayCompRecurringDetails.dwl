%dw 2.0

import modules::v2::commonDWFunctions


fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false


fun getEmpPayCompRecurrDetails(vEmpPayCompRecurrDetails,key) = 
	(
		if(vEmpPayCompRecurrDetails != null) 
			{
				"payCompRecurDetails": vEmpPayCompRecurrDetails.results default [] map ((payEmpCompRecurNav , indexOfResult) -> {
					("pay-component": payEmpCompRecurNav.payComponent) if(isKeyMatches(key,'compensation-details.emp-pay-comp-recurring-details.pay-component') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("start-date": commonDWFunctions::convertSFDate(payEmpCompRecurNav.startDate)) if(isKeyMatches(key,'compensation-details.emp-pay-comp-recurring-details.start-date') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("end-date": commonDWFunctions::convertSFDate(payEmpCompRecurNav.endDate)) if(isKeyMatches(key,'compensation-details.emp-pay-comp-recurring-details.end-date') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
					("pay-component-value": payEmpCompRecurNav.paycompvalue) if(isKeyMatches(key,'compensation-details.emp-pay-comp-recurring-details.pay-component-value') or isKeyMatches(key,'all') or isKeyMatches(key,'root')),
				})
			}
		else null
	) 