%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getDepartmentDetails(vDepartmentDetails,key) = 
	(
		if(vDepartmentDetails != null) 
			{
				("description": vDepartmentDetails.description) if(isKeyMatches(key,'department-details') or isKeyMatches(key,'job-details.department-details') or isKeyMatches(key,'job-details.department-details.description') or isKeyMatches(key,'all'))
			}
		else []
	) 