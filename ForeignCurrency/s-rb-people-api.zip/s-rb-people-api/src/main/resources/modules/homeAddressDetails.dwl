%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getHomeAddressDetails(vEmpDetails,key) = 
	(
		if(vEmpDetails != null) 
			{
				"homeAddressDetails":vEmpDetails.personNav.homeAddressNavDEFLT.results default [] map ((result , indexOfResult) -> {
					("address-type": result.addressType) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.addressType') or isKeyMatches(key,'all')),
					("start-date": commonDWFunctions::convertSFDate(result.startDate)) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.start-date') or isKeyMatches(key,'all')),
					("county": result.county) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.county') or isKeyMatches(key,'all')),
					("zip-code": result.zipCode) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.zip-code') or isKeyMatches(key,'all')),
					("address1": result.address1) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.address1') or isKeyMatches(key,'all')),
					("end-date": commonDWFunctions::convertSFDate(result.endDate)) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.end-date') or isKeyMatches(key,'all')),
					("address2": result.address2) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.address2') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(result.lastModifiedDateTime)) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.last-modified-date-time') or isKeyMatches(key,'all')),
					("state": result.stateNav.externalCode) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.state') or isKeyMatches(key,'all')),
					("country": result.country) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.country') or isKeyMatches(key,'all')),
					("city": result.city) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'person-details.home-address-details') or isKeyMatches(key,'person-details.home-address-details.city') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 