%dw 2.0

import modules::commonDWFunctions

//GLOBAL FUNCTIONS
fun getPaymentDetails(vUserDetails) = 
	(
		if(vUserDetails != null) 
			{
					"paymentDetails":vUserDetails.paymentInformationNav.results default [] map ((result , indexOfResult) -> {
					("effective-start-date": commonDWFunctions::convertSFDate(result.effectiveStartDate)) if(isEmpty(result.effectiveStartDate) == false),
					("last-modified-date-time": commonDWFunctions::convertSFDate(result.lastModifiedDateTime)) if(isEmpty(result.lastModifiedDateTime) == false),
					("effective-end-date": commonDWFunctions::convertSFDate(result.effectiveEndDate)) if(isEmpty(result.effectiveEndDate) == false),
					("account-number": result.toPaymentInformationDetailV3.results[0].accountNumber) if(isEmpty(result.toPaymentInformationDetailV3.results[0].accountNumber) == false),
					("bank": result.toPaymentInformationDetailV3.results[0].bank) if(isEmpty(result.toPaymentInformationDetailV3.results[0].bank) == false),
					("routing-number": result.toPaymentInformationDetailV3.results[0].routingNumber) if(isEmpty(result.toPaymentInformationDetailV3.results[0].routingNumber) == false),
					("iban": result.toPaymentInformationDetailV3.results[0].iban) if(isEmpty(result.toPaymentInformationDetailV3.results[0].iban) == false)
				})
			}
		else []
	) 