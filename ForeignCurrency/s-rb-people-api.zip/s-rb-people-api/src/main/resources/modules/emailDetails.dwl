%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getEmailDetails(vEmailDetails,key) = 
	(
		if(vEmailDetails != null) 
			{
				"emailDetails":vEmailDetails default [] map ((emailNav , indexOfResult) -> {
					("email-type": emailNav.emailTypeNav.picklistLabels.results[0].label) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-type') or isKeyMatches(key,'all')),
					("email-address": emailNav.emailAddress) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.email-address') or isKeyMatches(key,'all')),
					("last-modified-date-time": commonDWFunctions::convertSFDate(emailNav.lastModifiedDateTime)) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'person-details.email-details') or isKeyMatches(key,'person-details.email-details.last-modified-date-time') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 