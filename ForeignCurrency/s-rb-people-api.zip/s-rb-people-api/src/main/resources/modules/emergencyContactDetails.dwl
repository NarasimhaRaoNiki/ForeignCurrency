%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getEmergencyContactDetails(vEmergencyDetails,key) = 
	(
		if(vEmergencyDetails != null) 
			{
				"emergencyContactDetails":vEmergencyDetails default [] map ((emergencyContactNav , indexOfResult) -> {
					("name": emergencyContactNav.name) if(isKeyMatches(key,'emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details.name') or isKeyMatches(key,'all')),
					("email": emergencyContactNav.email) if(isKeyMatches(key,'emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details.email') or isKeyMatches(key,'all')),
					("phone": emergencyContactNav.phone) if(isKeyMatches(key,'emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details') or isKeyMatches(key,'person-details.emergency-contact-details.phone') or isKeyMatches(key,'all'))
				})
			}
		else null
	) 

