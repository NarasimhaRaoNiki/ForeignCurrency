%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getPersonalDetails(vEmpDetails,key) = 
	(
		if(vEmpDetails != null) 
			{
				("start-date": commonDWFunctions::convertSFDate(vEmpDetails.personNav.personalInfoNav.results[0].startDate)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.start-date') or isKeyMatches(key,'all')),
				("date-of-birth": commonDWFunctions::convertSFDate(vEmpDetails.personNav.personalInfoNav.results[0].dateOfBirth)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.date-of-birth') or isKeyMatches(key,'all')),
				("date-of-death": commonDWFunctions::convertSFDate(vEmpDetails.personNav.personalInfoNav.results[0].dateOfDeath)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.date-of-death') or isKeyMatches(key,'all')),
				("challenge-status": vEmpDetails.personNav.personalInfoNav.results[0].challengeStatus) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.challenge-status') or isKeyMatches(key,'all')),
				("gender": vEmpDetails.personNav.personalInfoNav.results[0].gender) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.gender') or isKeyMatches(key,'all')),
				("first-name": vEmpDetails.personNav.personalInfoNav.results[0].firstName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.first-name') or isKeyMatches(key,'all')),
				("last-name": vEmpDetails.personNav.personalInfoNav.results[0].lastName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.last-name') or isKeyMatches(key,'all')),
				("middle-name": vEmpDetails.personNav.personalInfoNav.results[0].middleName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.middle-name') or isKeyMatches(key,'all')),
				("birth-name": vEmpDetails.personNav.personalInfoNav.results[0].birthName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.birth-name') or isKeyMatches(key,'all')),
				("formal-name": vEmpDetails.personNav.personalInfoNav.results[0].formalName) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.formal-name') or isKeyMatches(key,'all')),
				("marital-status": vEmpDetails.personNav.personalInfoNav.results[0].maritalStatusNav.picklistLabels.results[0].label) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.marital-status') or isKeyMatches(key,'all')),
				("salutation": vEmpDetails.personNav.personalInfoNav.results[0].salutationNav.picklistLabels.results[0].label) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.salutation') or isKeyMatches(key,'all')),
				("end-date": commonDWFunctions::convertSFDate(vEmpDetails.personNav.personalInfoNav.results[0].endDate)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.end-date') or isKeyMatches(key,'all')),
				("last-modified-date-time": commonDWFunctions::convertSFDate(vEmpDetails.personNav.personalInfoNav.results[0].lastModifiedDateTime)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.personal-details.last-modified-date-time') or isKeyMatches(key,'all'))
  			}
		else null
	) 