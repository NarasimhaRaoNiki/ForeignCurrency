%dw 2.0

import * from dw::core::Arrays

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false

import modules::commonDWFunctions
import modules::personalDetailsMapping
import modules::homeAddressDetails
import modules::phoneDetails
import modules::emailDetails
import modules::emergencyContactDetails

//GLOBAL FUNCTIONS
fun getPersonDetails(vEmpDetails,key) = 
	(
		if(vEmpDetails != null) 
			{
				("network-id": vEmpDetails.personNav."customString1") if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'person-details.personal-details') or isKeyMatches(key,'person-details.network-id') or isKeyMatches(key,'all')),
  				("person-id-external": vEmpDetails.personNav.personIdExternal) if(isKeyMatches(key,'person-details') or isKeyMatches(key,'person-details.person-id-external') or isKeyMatches(key,'all')),
				// to add personNav details in v2
				("personal-details":personalDetailsMapping::getPersonalDetails(vEmpDetails,key)) if(isKeyMatches(key,'personal-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['personal-details'],key)),
				("home-address-details":homeAddressDetails::getHomeAddressDetails(vEmpDetails,key).homeAddressDetails) if(isKeyMatches(key,'home-address-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['home-address-details'],key)),
				("phone-details":phoneDetails::getPhoneDetails(vEmpDetails.personNav.phoneNav.results,key).phoneDetails default []) if(isKeyMatches(key,'phone-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['phone-details'],key)),
				("email-details":emailDetails::getEmailDetails(vEmpDetails.personNav.emailNav.results,key).emailDetails default []) if(isKeyMatches(key,'email-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['email-details'],key)),
				("emergency-contact-details":emergencyContactDetails::getEmergencyContactDetails(vEmpDetails.personNav.emergencyContactNav.results,key).emergencyContactDetails default []) if(isKeyMatches(key,'emergency-contact-details') or isKeyMatches(key,'all') or checkIfKeyConsistsChildEntities(['emergency-contact-details'],key))
			}
		else null
	) 