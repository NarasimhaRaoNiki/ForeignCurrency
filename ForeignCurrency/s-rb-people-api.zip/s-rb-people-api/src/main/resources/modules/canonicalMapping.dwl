%dw 2.0

output application/json

import * from dw::core::Arrays

import modules::commonDWFunctions
import modules::companyDetailsMapping
import modules::userDetails
import modules::jobDetails
import modules::paymentDetails
import modules::personDetails


var jobDetailsSubEntities=['job-details','job-code-details','department-details','manager-details','location-details','job-address-details','all']
var personDetailsSubEntities= ['person-details','personal-details','home-address-details','phone-details','email-details','all']

//var token = if (sizeOf((payload.d."__next")>0)) (((payload.d."__next" splitBy ("skiptoken="))[1] splitBy("&"))[0]) else ""
//var token = ((payload.d."__next" splitBy ("skiptoken="))[1] splitBy("&"))[0]
var token = if (isEmpty(payload.d."__next")) "" else (((payload.d."__next" splitBy ("skiptoken="))[1] splitBy("&"))[0])

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false
fun checkIsJobMatches(arr)= if(isKeyMatches(arr,'job-details') or isKeyMatches(arr,'job-code-details') or isKeyMatches(arr,'location-details') or isKeyMatches(arr,'job-address-details') or isKeyMatches(arr,'all'))
							true
							else false

fun checkIfKeyConsistsChildEntities(parent,keys) = if(sizeOf((keys map ((key,index) ->{
											"check":parent some (key as String contains $)
												})).check find true) !=0) true else false
							
fun checkIspersonDetailsMatches(arr) = if(isKeyMatches(arr,'person-details') or isKeyMatches(arr,'personal-details') or isKeyMatches(arr,'home-address-details') or isKeyMatches(arr,'phone-details') or isKeyMatches(arr,'email-details') or isKeyMatches(arr,'all'))
										true else false
										
var getNextUrlQueryParams = (if(isEmpty(attributes.queryParams.select) == false) ("select="++ attributes.queryParams.select ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.filter) == false) ("filter="++ attributes.queryParams.filter ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.expand) == false) ("expand="++ attributes.queryParams.expand ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.orderby) == false) ("orderby="++ attributes.queryParams.orderby ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.limit) == false) ("limit="++ attributes.queryParams.limit ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.leap) == false) ("leap="++ attributes.queryParams.leap ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.paging) == false) ("paging="++ attributes.queryParams.paging ++ "&") else "") ++
					  (if(isEmpty(attributes.queryParams.pagesize) == false) ("pagesize="++ attributes.queryParams.pagesize ++ "&") else "") ++
                      if(isEmpty(token) == false)("skiptoken="++ token) else ""

---

{
	"acknowledgment": {
		"message-id": correlationId,
    	"status": "Success",
    	"next-batch-token":token
    },
	"employee-details": payload.d.results default [] map ((emp , indexOfEmp) -> {
		("start-date": commonDWFunctions::convertSFDate(emp.startDate)) if(isKeyMatches(vars.vSelect,'start-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("payroll-end-date": commonDWFunctions::convertSFDate(emp.payrollEndDate)) if(isKeyMatches(vars.vSelect,'payroll-end-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
	    ("last-date-worked": commonDWFunctions::convertSFDate(emp.lastDateWorked)) if(isKeyMatches(vars.vSelect,'last-date-worked') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("benefits-eligibility-start-date": commonDWFunctions::convertSFDate(emp.benefitsEligibilityStartDate)) if(isKeyMatches(vars.vSelect,'benefits-eligibility-start-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("bonus-pay-expiration-date": commonDWFunctions::convertSFDate(emp.bonusPayExpirationDate)) if(isKeyMatches(vars.vSelect,'bonus-pay-expiration-date') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("rb-user-name": emp.customString2) if(isKeyMatches(vars.vSelect,'rb-user-name') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("last-modified-date-time": commonDWFunctions::convertSFDate(emp.lastModifiedDateTime)) if(isKeyMatches(vars.vSelect,'last-modified-date-time') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),	
		("user-id": emp.userId) if(isKeyMatches(vars.vSelect,'user-id') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("person-id-external": emp.personIdExternal) if(isKeyMatches(vars.vSelect,'person-id-external') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("is-contingent-worker": emp.isContingentWorker) if(isKeyMatches(vars.vSelect,'is-contingent-worker') or isKeyMatches(vars.vSelect,'root') or isKeyMatches(vars.vSelect,'all')),
		("job-details":jobDetails::getJobDetails(emp,vars.vSelect)."job-details") if(checkIsJobMatches(vars.vSelect) or checkIfKeyConsistsChildEntities(jobDetailsSubEntities,vars.vSelect)),
		("person-details":personDetails::getPersonDetails(emp,vars.vSelect)) if(checkIspersonDetailsMatches(vars.vSelect) or checkIfKeyConsistsChildEntities(personDetailsSubEntities,vars.vSelect)),
		("company-details":((companyDetailsMapping::getCompanyDetails(emp.compInfoNav.results,vars.vSelect))."company-details")) if(isKeyMatches(vars.vSelect,'company-details') or isKeyMatches(vars.vSelect,'all')),
		("user-details":userDetails::getUserDetails(emp,vars.vSelect)) if(isKeyMatches(vars.vSelect,'user-details') or isKeyMatches(vars.vSelect,'all') or checkIfKeyConsistsChildEntities(['user-details'],vars.vSelect)),
		})
}