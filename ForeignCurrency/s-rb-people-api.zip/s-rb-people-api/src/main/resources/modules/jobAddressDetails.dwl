%dw 2.0

import modules::commonDWFunctions

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getAddressDetails(vAddressDetails,key) = 
	(
		if(vAddressDetails != null) 
			{
				
				("location-county": vAddressDetails.county) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-county') or isKeyMatches(key,'all')),
				("location-zip-code": vAddressDetails.zipCode) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-zip-code') or isKeyMatches(key,'all')),
				("location-state": vAddressDetails.stateNav.picklistLabels.results[0].label) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-state') or isKeyMatches(key,'all')),
				("location-address1": vAddressDetails.address1) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-address1') or isKeyMatches(key,'all')),
				("location-address2": vAddressDetails.address2) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-address2') or isKeyMatches(key,'all')),
				("location-address3": vAddressDetails.address3) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-address3') or isKeyMatches(key,'all')),
				("location-city": vAddressDetails.city) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-city') or isKeyMatches(key,'all')),
				("location-country": vAddressDetails.country) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.location-country') or isKeyMatches(key,'all')),
				("last-modified-date-time": commonDWFunctions::convertSFDate(vAddressDetails.lastModifiedDateTime)) if(isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'job-details.location-details.address-details.last-modified-date-time') or isKeyMatches(key,'all'))
			}
		else []
	) 