%dw 2.0

import modules::employeeDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getManagerDetails(vManagerDetails,key) = 
	(
		if(vManagerDetails != null) 
			{
				("manager-id": vManagerDetails.userId) if(isKeyMatches(key,'manager-details') or isKeyMatches(key,'job-details.manager-details') or isKeyMatches(key,'job-details.manager-details.manager-id') or isKeyMatches(key,'all')),
				("employee-details": employeeDetails::getEmployeeDetails(vManagerDetails.empInfo,key)) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.network-id') or isKeyMatches(key,'all'))
			}
		else []
	) 