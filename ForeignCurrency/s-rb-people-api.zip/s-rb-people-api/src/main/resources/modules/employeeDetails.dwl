%dw 2.0

import modules::employeeDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getEmployeeDetails(vEmployeeDetails,key) = 
	(
		if(vEmployeeDetails != null) 
			{
				("person-details": getPersonalDetails(vEmployeeDetails.personNav,key)) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.network-id') or isKeyMatches(key,'all'))
			}
		else []
	) 
	
// Custom Personal Mapping	
fun getPersonalDetails(vPersonalDetails,key) =

(
	if(vPersonalDetails != null)
		{
			("network-id": vPersonalDetails.customString1) if(isKeyMatches(key,'job-details.manager-details.employee-details.person-details.network-id') or isKeyMatches(key,'all'))
				
		}
	else []
	)