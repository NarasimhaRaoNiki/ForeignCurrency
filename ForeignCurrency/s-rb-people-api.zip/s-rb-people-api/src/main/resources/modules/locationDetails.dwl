%dw 2.0

import modules::commonDWFunctions
import modules::jobAddressDetails

fun isKeyMatches(arr,key)= if (sizeOf(arr find key) !=0) true else false

//GLOBAL FUNCTIONS
fun getLocationDetails(vLocationDetails,key) = 
	(
		if(vLocationDetails != null) 
			{
				("name": vLocationDetails.externalCode) if (isKeyMatches(key,'location-details') or isKeyMatches(key,'job-details.location-details') or isKeyMatches(key,'job-details.location-details.name') or isKeyMatches(key,'all')),
				("address-details": jobAddressDetails::getAddressDetails(vLocationDetails.addressNavDEFLT,key)) if (isKeyMatches(key,'address-details') or isKeyMatches(key,'job-details.location-details.address-details') or isKeyMatches(key,'all'))
			}
		else []
	)
