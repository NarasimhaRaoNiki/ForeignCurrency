%dw 2.0
output application/json
---
{     
  "messageId": vars.vLogVars.messageId,
  "correlationId": correlationId,
  "transactionId":   vars.vLogVars.requestId,
  "environment": p('secure::mule.env'),
  "id": app.name,
  "name": app.name,
  "domain": p('secure::common.domain'),
  "muleProjectName": app.name,
  "muleFlowName": p('secure::flow.name.main'),
  "sourceSystem":  p('secure::mq.source.system'), // "ACTIVEMQ-QUEUE",
  "targetSystem":p('secure::mq.destination'),
  "logType": p('secure::status.error'),
  "logTimeStamp": now() as String {format: p('secure::mq.log.timestamp.format')} ,//"05-12-17_17-52-05.016",
  "logDetails": error.description default vars.vErrorMessage,
  "errorType": error.errorType.identifier default 'UNKNOWN',
  "errorCode": vars.httpStatus default "500",
  "muleComponentName": p('secure::mq.mulecomponent.name'),
  "errorDetails": error.detailedDescription,
  "errorStacktrace": error.cause.localizedMessage,
  "inputMessage": "",
  "containsSensitiveInformation": p('secure::casesensitive.flag')
}
