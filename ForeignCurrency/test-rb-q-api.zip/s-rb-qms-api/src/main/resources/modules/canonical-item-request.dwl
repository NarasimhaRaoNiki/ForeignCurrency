%dw 2.0
output application/json
---
payload map {
	"change_control__c" : $.'change-control',
	"external_id__c": $.'name' ++ '-' ++ $.'vault-id' ++ '_' ++ $.'change-control',
	"name__v" :  $.'name',
	"item_class__c" : $.'item-class',
	"item_name__c" : $.'item-name',
	"version__c" : $.'version',
	"status__c" : $.'status',
	"last_modified_date_integration__c" : $.'last-modified-date'	
}