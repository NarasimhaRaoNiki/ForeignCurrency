%dw 2.0
output application/json
---
payload map (value,ind) -> {
"sf_user_id__c" : value.'user-id',
"username__sys": value.'user-name',
"first_name__sys": value.'first-name',
"last_name__sys": value.'last-name',
"sf_preferred_name__c" : value.'preferred-name',
"email__sys": value.email,
"business_unit_name__c" : value.'business-unit-name',
"employee_region__c" : value.'employee-region',
"regulatory_region__c" : value.'regulatory-region',
"location__c": value.location,
"job_function_name__c" : value.'job-function-name',
"job_sub_function_name__c" : value.'job-sub-function-name',
"title__sys": value.title,
"sf_activation_date__c" : value.'sf-activation-date',
"sf_inactivation_date__c" : value.'sf-inactivation-date',
//("manager__sys.email__sys" : value.manager) if (value.manager != ""),
//("manager__sys" : value.manager) if(value.manager == ""),
("manager__sys.sf_employee_id__c" : value.manager) if (value.manager != ""),
("manager__sys" : value.manager) if(value.manager == ""),
"federated_id__sys":value.email,
"sf_employee_id__c" : value.'employee-id',
"sf_network_id__c" : value.'network-id',
"language__sys.name__v" : value.language,
"locale__sys.name__v": value.locale,
//"license_type__v": value.'license_type',
("security_profile__sys.name__v": value.'security-profile') if(value.'employee-status' == false),
("security_policy__sys.name__v": value.'security-policy') if(value.'employee-status' == false), 
"timezone__sys" : value.timezone
}