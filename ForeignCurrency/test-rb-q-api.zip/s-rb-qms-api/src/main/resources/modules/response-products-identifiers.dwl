%dw 2.0
output application/json
---
payload.data map {
    "name": $.name__v default "",
    "legacy-object-id1": $.legacy_object_id__c default "",
    "brief-description": $.brief_description__v default "",
    "state": $.state__v  default ""
} 