%dw 2.0
output application/java
---
(((payload map {
	
    "name__v" : " name__v = '" ++ $.'change-control' ++ "' " ++ "or "
}).name__v) reduce ((val, acc) -> acc ++ val))[0 to -5] default []