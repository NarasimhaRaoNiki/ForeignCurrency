%dw 2.0
output application/json
fun getStatus(vPayload)=
(
	if(sizeOf(payload.data filter($.responseStatus == "SUCCESS")) > 0 and sizeOf(payload.data filter($.responseStatus != "SUCCESS")) > 0) 
		p('secure::status.warning')
	else if(sizeOf(payload.data filter($.responseStatus == "SUCCESS")) > 0 and sizeOf(payload.data filter($.responseStatus != "SUCCESS")) == 0) 
		p('secure::status.success')
	else p('secure::status.error')
)
---
{
	acknowledgment:{
		"message-id": vars.vLogVars.messageId,
		"status": getStatus(payload),
		"description": if(getStatus(payload) == p('secure::status.success')) p('secure::qms.status.success.description')
						else if(getStatus(payload) == p('secure::status.warning')) p('secure::qms.status.warning.description')
						else p('secure::qms.status.error.description'),
		(errors: [
            {
                "error-code": p('secure::app.name') ++ p('secure::code.br2'),
                "error-description": if(getStatus(payload) == p('secure::status.warning')) p('secure::qms.status.warning.description')
						else p('secure::qms.status.error.description')
            }
            
            
        ]) if(sizeOf(payload.data filter($.responseStatus != "SUCCESS")) > 0)
    }
	
}