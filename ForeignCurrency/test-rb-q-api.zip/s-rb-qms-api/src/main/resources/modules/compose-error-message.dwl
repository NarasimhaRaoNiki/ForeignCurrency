%dw 2.0
output application/json
---
{ 
  "acknowledgment": {
    "message-id": vars.vLogVars.messageId,
    "status": p('secure::status.error'),
    "description": p('secure::error.description'),
    "errors": [
      {
        "error-code": vars.httpStatus default "500",
        "error-description": vars.vErrorMessage
      }
    ]
  }
}
