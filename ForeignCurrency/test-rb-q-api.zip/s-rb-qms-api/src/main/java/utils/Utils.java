package utils;

import java.util.Iterator;

  
class DummyIterator implements Iterator<String> { 
      
    public boolean valid= true;

    public DummyIterator() 
    { 
    	this.valid = true;
    } 
      
    // returns false if next element does not exist 
    public boolean hasNext() 
    { 
        return this.valid;
    } 
      
    
    public void stop()
    {
    	this.valid = false;
    	
    }
    
    public String next() 
    { 
    	String s = (String) "dummy";
    	if (this.valid)
    		return s;
    	else 
    		return null;
    } 
      
    public void remove() 
    { 
        throw new UnsupportedOperationException(); 
    } 
} 
  



public class Utils {
	
	
	public static DummyIterator getCustomIterator() {
		DummyIterator  di = new DummyIterator();
		return di;
	}
	
	public static void stopCustomIterator(DummyIterator di) {
		di.stop();
	}
	
	public static boolean getCustomIteratorStatus(DummyIterator di) {
		return di.valid;
	}
	
	

}